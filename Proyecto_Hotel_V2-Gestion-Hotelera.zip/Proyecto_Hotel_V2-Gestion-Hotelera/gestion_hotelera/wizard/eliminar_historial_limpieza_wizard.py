from odoo import models, fields
from odoo.exceptions import UserError

# ============================================================
# WIZARD 1 → Seleccionar Fechas
# ============================================================
class EliminarHistorialLimpiezaWizard(models.TransientModel):
    _name = 'eliminar.historial.limpieza.wizard'
    _description = 'Eliminar registros de historial - Limpieza'

    fecha_inicio = fields.Date(string="Desde", required=True)
    fecha_fin = fields.Date(string="Hasta", required=True)

    def action_validar(self):
        """Valida fechas y si hay registros, abre confirmación."""
        if self.fecha_fin < self.fecha_inicio:
            raise UserError("⚠️ La fecha final no puede ser anterior a la inicial.")
        
        historial_stage = self.env.ref(
            'gestion_hotelera.stage_limpieza_historial',
            raise_if_not_found=False
        )
        if not historial_stage:
            raise UserError("❌ No se encontró la etapa 'Historial'.")

        registros = self.env['hotel.limpieza'].search([
            ('stage_id', '=', historial_stage.id),
            ('fecha_fin', '>=', self.fecha_inicio),
            ('fecha_fin', '<=', self.fecha_fin)
        ])

        if not registros:
            raise UserError("⚠️ No se encontraron registros en ese rango de fechas.")

        # Abrir confirmación
        return {
            'name': "Confirmar eliminación",
            'type': 'ir.actions.act_window',
            'res_model': 'confirmar.eliminar.limpieza.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_fecha_inicio': self.fecha_inicio,
                'default_fecha_fin': self.fecha_fin,
            },
        }

# ============================================================
# WIZARD 2 → Confirmar Eliminación
# ============================================================
class ConfirmarEliminarLimpiezaWizard(models.TransientModel):
    _name = 'confirmar.eliminar.limpieza.wizard'
    _description = 'Confirmación de eliminación del historial de limpieza'

    fecha_inicio = fields.Date()
    fecha_fin = fields.Date()

    def action_confirmar_eliminacion(self):
        """Elimina definitivamente los registros del historial."""
        historial_stage = self.env.ref(
            'gestion_hotelera.stage_limpieza_historial',
            raise_if_not_found=False
        )
        if not historial_stage:
            raise UserError("❌ No se encontró la etapa 'Historial'.")

        registros = self.env['hotel.limpieza'].search([
            ('stage_id', '=', historial_stage.id),
            ('fecha_fin', '>=', self.fecha_inicio),
            ('fecha_fin', '<=', self.fecha_fin)
        ])

        count = len(registros)
        registros.unlink()

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': '🧹 Historial limpieza',
                'message': f'Se eliminaron {count} registros del historial.',
                'sticky': False,
                'type': 'success',
                'next': {'type': 'ir.actions.client', 'tag': 'reload'},
            }
        }
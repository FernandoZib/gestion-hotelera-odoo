from odoo import models, fields, api, _
from odoo.exceptions import UserError
from datetime import datetime, timedelta # 👈 Necesario para la manipulación de fechas
from pytz import timezone # 👈 Necesario para el manejo de zona horaria

class ReservaCancelWizard(models.TransientModel):
    _name = 'hotel.reserva.cancel.wizard'
    _description = 'Wizard para Motivo de Cancelación de Reserva'
    
    # 💡 1. AÑADIR MÉTODO DEFAULT para forzar la carga de reserva_id
    def _default_reserva_id(self):
        reserva_id = self._context.get('default_reserva_id') or self._context.get('active_id')
        if not reserva_id:
            raise UserError(_("No se pudo identificar la reserva a cancelar."))
        return reserva_id

    reserva_id = fields.Many2one(
        'hotel.reserva',
        string='Reserva a Cancelar',
        required=True,
        # 💡 Aplicar el valor por defecto
        default=_default_reserva_id 
    )
    
    motivo_cancelacion = fields.Selection(
        [
            ('cambio_planes', 'Cambio de planes'),
            ('problemas_personales', 'Problemas personales o dificultades para llegar al hotel'),
            ('reserva_duplicada', 'Reserva duplicada'),
            ('inconformidad_checkin', 'Inconformidad antes del check-in'),
            ('incumplimiento_pago', 'Incumplimiento de pago'),
            ('no_show', 'No-show'),
            ('info_falsa', 'Información falsa o incompleta'),
            ('violacion_politicas', 'Violación de políticas o conducta inapropiada del huésped'),
            ('problemas_internos', 'Problemas internos del hotel'), # 👈 El motivo que dispara el mantenimiento
            ('otro', 'Otro (Especificar)') # 👈 NUEVO MOTIVO
        ],
        string='Motivo de Cancelación',
        required=True,
        help='Seleccione el motivo de la cancelación de la reserva.'
    )

    # 🚀 NUEVO CAMPO: Para ingresar el texto si el motivo es 'otro'
    texto_motivo_otro = fields.Text(
        string="Especificar Motivo",
        help="Ingrese el motivo de cancelación si seleccionó 'Otro'."
    )

    # ============================================================
    # ACCIÓN PARA CONFIRMAR LA CANCELACIÓN (MODIFICADO)
    # ============================================================
    def action_confirmar_cancelacion(self):
        self.ensure_one()
        if not self.reserva_id.exists():
            raise UserError(_("La reserva a cancelar no es válida o ha sido eliminada."))
            
        cancelada_stage = self.env.ref('gestion_hotelera.cancelada', raise_if_not_found=False)

        # 1. 🚀 LÓGICA: CREAR MANTENIMIENTO SI EL MOTIVO ES INTERNO
        if self.motivo_cancelacion == 'problemas_internos':
            self._crear_mantenimiento_por_cancelacion() # Llamamos a la nueva función
            
        # 2. OBTENER EL VALOR DE SELECCIÓN Y GUARDARLO EN NOTAS
        motivo_display_name = dict(self.fields_get(['motivo_cancelacion'])['motivo_cancelacion']['selection'])[self.motivo_cancelacion]

        # 💡 ADICIÓN: Añadir el texto manual si el motivo es 'otro'
        if self.motivo_cancelacion == 'otro' and self.texto_motivo_otro:
            motivo_display_name += f": {self.texto_motivo_otro}"
        elif self.motivo_cancelacion == 'otro' and not self.texto_motivo_otro:
             raise UserError(_("Debe especificar el motivo en el campo de texto si selecciona 'Otro'."))
        
        
        fecha_cancelacion = fields.Datetime.now()
        motivo_completo = f"❌ CANCELADA el {fecha_cancelacion.strftime('%Y-%m-%d %H:%M:%S')} - Motivo: {motivo_display_name}"
        
        # Añadir al campo notas de la reserva
        notas_actuales = self.reserva_id.notas or ""
        nuevas_notas = f"{notas_actuales}\n\n{motivo_completo}".strip()

        if not cancelada_stage:
             raise UserError(_("No se encontró la etapa 'Cancelada'. Asegúrese de que el XML externo es correcto."))

        # 3. ESCRIBIR EN EL CAMPO 'notas' y cambiar el stage
        self.reserva_id.with_context(skip_cancel_wizard=True).write({
            'notas': nuevas_notas,
            'stage_id': cancelada_stage.id,
        })

        # 4. DEVOLVER ACCIÓN ÚNICA para cerrar el wizard y recargar la vista.
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }
    
    # ============================================================
    # FUNCIÓN AUXILIAR PARA CREAR MANTENIMIENTO (CORREGIDA)
    # ============================================================
    def _crear_mantenimiento_por_cancelacion(self):
        self.ensure_one()
        
        # 1. Obtener la etapa "Nuevo" para el mantenimiento (Requerido)
        stage_nuevo = self.env.ref('gestion_hotelera.stage_mantenimiento_nuevo', raise_if_not_found=False)
        if not stage_nuevo:
             raise UserError(_("No se encontró la etapa inicial 'Nuevo' para Mantenimiento."))

        # 2. Obtener la Habitación (Record Set COMPLETO)
        # 💡 CORRECCIÓN: Definimos la variable 'habitacion' correctamente aquí
        habitacion = self.reserva_id.habitacion_id 
        if not habitacion:
            # No se puede crear mantenimiento sin habitación.
            return 
            
        # 3. Obtener el Responsable (El primer empleado encontrado)
        responsable = self.env['hr.employee'].search([], limit=1)
        if not responsable:
            raise UserError(_("No se encontraron empleados disponibles para asignar el mantenimiento."))
        
        # 4. Calcular Fechas y Hora (De 12:00 a 13:00 del día en curso)
        tz_name = self.env.user.tz or self.env.company.partner_id.tz or 'America/Mexico_City'
        tz_mx = timezone(tz_name)
        
        ahora_local = fields.Datetime.now().astimezone(tz_mx)
        
        fecha_inicio_local = ahora_local.replace(hour=12, minute=0, second=0, microsecond=0)
        fecha_fin_local = ahora_local.replace(hour=13, minute=0, second=0, microsecond=0)
        
        fecha_inicio_utc = fecha_inicio_local.astimezone(timezone('UTC')).replace(tzinfo=None)
        fecha_fin_utc = fecha_fin_local.astimezone(timezone('UTC')).replace(tzinfo=None)
        
        # 5. Crear el registro de Mantenimiento
        vals = {
            'name': 'Mantenimiento por Cancelación de Reserva',
            'stage_id': stage_nuevo.id,
            # 💡 CORRECCIÓN: Ahora 'habitacion' está definida y usamos su ID
            'id_habitacion': habitacion.id, 
            'empleado_ids': [(6, 0, responsable.ids)], 
            'fecha_inicio_mnt': fecha_inicio_utc,
            'fecha_fin_mnt': fecha_fin_utc,
            # 💡 CORRECCIÓN: Usamos 'habitacion.name' sin error
            'observaciones': _(f"Mantenimiento creado automáticamente por la cancelación de la Reserva ({self.reserva_id.display_name}) de la habitación {habitacion.name} debido a 'Problemas Internos del Hotel'."),
        }
        
        self.env['hotel.mantenimiento'].create(vals)
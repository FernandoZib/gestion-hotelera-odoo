from odoo import models, fields, api
from odoo.exceptions import ValidationError

class HotelDashboard(models.Model):
    _name = 'hotel.dashboard'
    _description = 'Panel Principal del Hotel'

    name = fields.Char(string="Nombre", default="Panel Principal", readonly=True)

    @api.model_create_multi
    def create(self, vals_list):
        # Aseguramos que siempre sea una lista de diccionarios
        if self.search_count([]) + len(vals_list) > 1:
            raise ValidationError("Solo puede existir un registro del Panel de Control.")

        records = super().create(vals_list)
        return records

    def unlink(self):
        raise ValidationError("No es posible eliminar el registro del Panel de Control.")

    # -----------------------
    # Métodos para abrir acciones
    # -----------------------
    def action_open_habitacion(self):
        return self.env.ref('gestion_hotelera.action_hotel_habitacion').read()[0]

    def action_open_limpieza(self):
        return self.env.ref('gestion_hotelera.action_hotel_limpieza').read()[0]

    def action_open_reserva(self):
        return self.env.ref('gestion_hotelera.action_hotel_reserva').read()[0]

    def action_open_mantenimiento(self):
        return self.env.ref('gestion_hotelera.action_hotel_mantenimiento').read()[0]

    def action_open_precios(self):
        return self.env.ref('gestion_hotelera.action_hotel_precio').read()[0]

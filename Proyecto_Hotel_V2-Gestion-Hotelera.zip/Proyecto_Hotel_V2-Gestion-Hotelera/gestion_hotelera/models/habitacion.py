from odoo import models, fields, api

class Habitacion(models.Model):
    _name = 'hotel.habitacion'
    _description = 'Habitación del hotel'
    _inherit = 'mail.thread', 'mail.activity.mixin'

    name = fields.Char(string='Número o Nombre de Habitación', required=True)
    descripcion = fields.Text(string='Descripción')
    stage_id = fields.Many2one(
            'hotel.habitacion.stage',
            string='Estado',
            tracking=True,
            group_expand='expand_stages',
            default=lambda self: self.env.ref('gestion_hotelera.stage_disponible'))
    
    tipo_habitacion_id = fields.Many2one(
            'hotel.habitacion.tipo',
            string='Tipo de Habitación',
            required=True)

    tipo_habitacion_maxpersonas = fields.Integer(
            string="Máximo de Personas",
            related='tipo_habitacion_id.max_personas',
            readonly=True) 

    #funcion para agregar los stages kanban
    @api.model
    def expand_stages(self, stages, domain):
        """Devuelve todos los stages aunque no haya habitaciones."""
        #return self.env['hotel.habitacion.stage'].search([], order=order)
        stage_ids = stages.sudo()._search([], order=stages._order)
        return stages.browse(stage_ids)

    #funcion para cambiar los colores de fondo en kanban
    @api.depends('stage_id')
    def _compute_kanban_color(self):
        for record in self:
            if record.stage_id.name == 'Disponible':
                record.kanban_color = 'disponible'  # Verde claro
            elif record.stage_id.name == 'Ocupada':
                record.kanban_color = 'ocupada'  # Rojo claro
            elif record.stage_id.name == 'En Limpieza':
                record.kanban_color = 'limpieza'  # Amarillo claro
            elif record.stage_id.name == 'En Mantenimiento':
                record.kanban_color = 'mantenimiento'  # Azul claro
            else:
                record.kanban_color = 'defecto'  # Blanco por defecto
# -*- coding: utf-8 -*-
# Importaciones necesarias para el funcionamiento del modelo de Odoo y manejo de fechas.
import pytz
import logging
from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError
from datetime import datetime, timedelta
from pytz import timezone

# Configuración del logger para mensajes de depuración e información.
_logger = logging.getLogger(__name__)


# =========================================================================
# CLASE PRINCIPAL: HotelMantenimiento
# Modelo para la gestión y seguimiento de las órdenes de mantenimiento en las habitaciones del hotel.
# Hereda de 'mail.thread' y 'mail.activity.mixin' para habilitar seguimiento y actividades.
# =========================================================================
class HotelMantenimiento(models.Model):
    _name = 'hotel.mantenimiento'
    _description = 'Gestión del Mantenimiento'
    _order = 'fecha_inicio_mnt desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    # -----------------------------------------
    # CAMPOS DEL MODELO
    # Definición de todos los atributos y datos que almacena el registro de mantenimiento.
    # -----------------------------------------
    name = fields.Char(string='Código', readonly=True, copy=False, default='MNT00', tracking=True)
    
    # Campo para almacenar el estado actual del mantenimiento (Nuevo, En Progreso, Finalizado, etc.).
    stage_id = fields.Many2one(
        'hotel.mantenimiento.stage',
        string='Estado',
        required=True,
        tracking=True,
        group_expand='expand_stages',
        default=lambda self: self.env.ref('gestion_hotelera.stage_mantenimiento_nuevo', raise_if_not_found=False)
    )
    
    id_habitacion = fields.Many2one('hotel.habitacion', string='Habitación:', required=True, tracking=True)
    empleado_ids = fields.Many2many('hr.employee', string='Responsables:', required=True, tracking=True)
    
    # Campo calculado para mostrar los nombres de los empleados responsables de forma concisa.
    empleado_nombres = fields.Char(string="Responsables", compute="_compute_empleado_nombres", tracking=True)
    
    fecha_inicio_mnt = fields.Datetime(string='Fecha de inicio:', tracking=True)
    fecha_fin_mnt = fields.Datetime(string='Fecha de fin:', tracking=True)
    costo_mantenimiento = fields.Monetary(string='Costo del Mantenimiento:', currency_field='currency_id', tracking=True)
    currency_id = fields.Many2one('res.currency', string='Moneda', default=lambda self: self.env.company.currency_id, tracking=True)
    observaciones = fields.Text(string='Notas u observaciones')
    
    # Campo booleano calculado para indicar si la orden se encuentra en la etapa 'Historial'.
    is_historial = fields.Boolean(string='Es Historial', compute='_compute_is_historial', store=True, tracking=True)
    
    # Campo calculado para visualizar el progreso porcentual del mantenimiento. (Actualizado)
    progreso = fields.Float(string='Progreso (%)', compute='_compute_progreso', store=True, tracking=True)
    
    # Campo calculado para asignar un color a la tarea en la vista de Gantt. (Actualizado)
    color = fields.Integer(string='Color', compute='_compute_color_gantt', store=False)
    
    # Campo calculado para asignar una clase de color para la vista Kanban. (Actualizado)
    color_class = fields.Char(string='Color Kanban', compute='_compute_color_class', store=True)

    # Campo nuevo: Color para mostrar en vistas de lista como badge HTML.
    color_list_html = fields.Html(string='Color Lista', compute='_compute_color_list_html', store=False)
    
    # Campo calculado para mostrar el nombre de la habitación en la vista de Gantt.
    campo_habitacion_gantt = fields.Char(string="Habitación (Gantt)", compute="_compute_campo_habitacion_gantt", store=True, tracking=True)
    
    # Campo calculado para mostrar los responsables en la vista de Gantt.
    encargado_gantt = fields.Char(string="Encargado (Gantt)", compute="_compute_encargado_gantt", store=True, tracking=True)
    
    # Campo de relación directa al estado interno de la etapa.
    estado_interno = fields.Selection(related="stage_id.estado_interno", store=True, tracking=True)
    
    # Selección para categorizar el tipo de mantenimiento.
    tipo_mantenimiento = fields.Selection([
        ('preventivo', 'Preventivo (Inspección/Rutina)'),
        ('correctivo', 'Correctivo (Avería/Fallo)'),
        ('estetico', 'Estético (Pintura/Mobiliario)'),
        ('emergencia', 'Emergencia (Urgente/Inmediato)'),
    ], string='Tipo de Mantenimiento', required=False, tracking=True)
    
    fecha_finalizado_mnt = fields.Datetime(string='Fecha de Finalización', readonly=True, tracking=True)
    
    # -----------------------------------------
    # FUNCIONES AUXILIARES DE FECHAS Y VALIDACIÓN
    # Métodos privados utilizados internamente para el manejo y validación de datos.
    # -----------------------------------------

    # Función para convertir una cadena a objeto datetime.
    def _to_datetime_if_string(self, value):
        """Convierte una cadena a objeto datetime si es necesario y la fecha no es Falsa."""
        if isinstance(value, str):
            try:
                # Intenta usar el formato estándar de Odoo
                return fields.Datetime.from_string(value)
            except ValueError:
                return False
        # Si el valor es False, None, o ya es datetime, lo devuelve
        return value
        
    # Función para validar el solapamiento de fechas.
    def _validate_overlap(self, room_id, start_date, end_date):
        """
        Valida el solapamiento de fechas con otras órdenes activas (Nuevo/Progreso)
        para la misma habitación, lanzando una ValidationError si se encuentra un conflicto.
        """
        if not room_id or not start_date or not end_date:
            return

        # 1. Obtener las etapas activas (se verifica que existan)
        stage_nuevo = self.env.ref('gestion_hotelera.stage_mantenimiento_nuevo', raise_if_not_found=False)
        stage_progreso = self.env.ref('gestion_hotelera.stage_mantenimiento_en_progreso', raise_if_not_found=False)
        allowed_stage_ids = [s.id for s in [stage_nuevo, stage_progreso] if s]

        if not allowed_stage_ids:
            _logger.warning("Faltan etapas Nuevo o En Progreso. La validación de solapamiento no se aplica.")
            return

        # 2. Validación de rango: inicio <= fin
        if start_date > end_date:
            raise ValidationError("❌ Error de Fechas: La Fecha de Inicio no puede ser posterior a la Fecha de Fin.")


        # 3. Filtro de búsqueda (Superposición):
        overlap_domain = [
            # Excluimos los IDs de los registros actuales (self.ids) para permitir la modificación
            ('id', 'not in', self.ids), 
            ('id_habitacion', '=', room_id),
            ('stage_id', 'in', allowed_stage_ids),
            # Condición de Solapamiento: A.inicio < B.fin Y A.fin > B.inicio
            ('fecha_inicio_mnt', '<', end_date),
            ('fecha_fin_mnt', '>', start_date),
        ]

        overlapping_orders = self.search(overlap_domain, limit=1)

        if overlapping_orders:
            room_name = self.env['hotel.habitacion'].browse(room_id).name if room_id else 'N/A'
            
            # Formatear las fechas como string antes de pasarlas al mensaje
            exist_start_str = fields.Datetime.to_string(overlapping_orders.fecha_inicio_mnt)
            exist_end_str = fields.Datetime.to_string(overlapping_orders.fecha_fin_mnt)
            new_start_str = fields.Datetime.to_string(start_date)
            new_end_str = fields.Datetime.to_string(end_date)
            
            # ----------------------------------------------------
            # MENSAJE DE ERROR CON SALTOS DE LÍNEA PARA FORMATO DESEADO
            # ----------------------------------------------------
            msg = (
                "¡Error de Superposición en Mantenimiento! \n\n"
                "La Habitación %(room_name)s ya tiene una orden activa \n"
                "(%(order_name)s) programada entre:\n\n"
                "%(exist_start)s y\n"
                "%(exist_end)s \n\n"
                "que se solapa con tu periodo:\n\n"
                "%(new_start)s a\n"
                "%(new_end)s \n\n"
                "Por favor, ajusta las fechas."
            )

            raise ValidationError(msg % {
                'room_name': room_name,
                'order_name': overlapping_orders.name,
                'exist_start': exist_start_str,
                'exist_end': exist_end_str,
                'new_start': new_start_str,
                'new_end': new_end_str,
            })

    # -----------------------------------------
    # MÉTODOS create() y write() OPTIMIZADOS
    # Métodos estándar de Odoo sobrescritos para incluir lógica de validación
    # y control de secuencia/etapas.
    # -----------------------------------------
    
    # Método sobrescrito para la creación de nuevos registros.
    @api.model_create_multi
    def create(self, vals_list):
        """
        Gestiona la validación de superposición ANTES de generar la secuencia (para evitar salto de ID al fallar)
        y establece un valor predeterminado para 'fecha_fin_mnt' si no se proporciona.
        """
        seq_obj = self.env['ir.sequence']
        processed_vals = []

        for vals in vals_list:
            
            # --- 1. Manejo y Cálculo de Fechas ---
            fecha_inicio_val = vals.get('fecha_inicio_mnt')
            fecha_fin_val = vals.get('fecha_fin_mnt')
            room_id = vals.get('id_habitacion')
            
            fecha_inicio_dt = self._to_datetime_if_string(fecha_inicio_val)
            
            # Cálculo de fecha_fin si no está provista (por defecto +1 hora)
            if fecha_inicio_dt and not fecha_fin_val:
                fecha_fin_dt = fecha_inicio_dt + timedelta(hours=1)
                vals['fecha_fin_mnt'] = fields.Datetime.to_string(fecha_fin_dt)
                fecha_fin_val = vals['fecha_fin_mnt']  # actualizar referencia local

            fecha_fin_dt = self._to_datetime_if_string(fecha_fin_val)

            # --- 2. VALIDACIÓN DE SOLAPAMIENTO ---
            # Si esta validación falla, se lanza el ValidationError y la secuencia NO se consume.
            self._validate_overlap(room_id, fecha_inicio_dt, fecha_fin_dt)

            # --- 3. GENERACIÓN DE SECUENCIA (Solo si las validaciones pasaron) ---
            if not vals.get('name') or vals.get('name') in ('MNT00', 'New', 'Nuevo'):
                try:
                    vals['name'] = seq_obj.next_by_code('hotel.mantenimiento.seq') or 'Nuevo'
                except Exception as e:
                    _logger.exception("Error generando secuencia para hotel.mantenimiento: %s", e)
                    vals['name'] = vals.get('name') or 'Nuevo' # Fallback

            processed_vals.append(vals)

        return super().create(processed_vals)

    # Método sobrescrito para la modificación de registros existentes.
    def write(self, vals):
        """
        Gestiona la validación de superposición en caso de cambio de fechas/habitación,
        controla las transiciones de etapas (no retroceder, ir a historial solo desde finalizada)
        y actualiza el estado de la habitación al pasar a 'En Progreso' o 'Finalizada'.
        """
        stage_obj = self.env['hotel.mantenimiento.stage']
        stage_historial = self.env.ref('gestion_hotelera.stage_mantenimiento_historial', raise_if_not_found=False)
        stage_finalizada = self.env.ref('gestion_hotelera.stage_mantenimiento_finalizada', raise_if_not_found=False)
        stage_en_progreso = self.env.ref('gestion_hotelera.stage_mantenimiento_en_progreso', raise_if_not_found=False)
        stage_disponible = self.env.ref('gestion_hotelera.stage_disponible', raise_if_not_found=False)
        stage_hab_mantenimiento = self.env.ref('gestion_hotelera.stage_mantenimiento', raise_if_not_found=False)

        for record in self:
            
            # --- A. VALIDACIÓN DE SUPERPOSICIÓN EN write ---
            if any(f in vals for f in ('fecha_inicio_mnt', 'fecha_fin_mnt', 'id_habitacion')):
                # Obtener los valores definitivos (nuevos si están en vals, o existentes)
                new_room = vals.get('id_habitacion', record.id_habitacion.id)
                new_start = self._to_datetime_if_string(vals.get('fecha_inicio_mnt', record.fecha_inicio_mnt))
                new_end = self._to_datetime_if_string(vals.get('fecha_fin_mnt', record.fecha_fin_mnt))
                
                # Validar solapamiento con otras órdenes activas antes de continuar
                self._validate_overlap(new_room, new_start, new_end)


            # --- B. LÓGICA DE ETAPAS ---
            if 'stage_id' in vals:
                new_stage = stage_obj.browse(vals['stage_id'])
                
                # Registro de fecha de finalización si se mueve a la etapa 'Finalizada'.
                if stage_finalizada and new_stage.id == stage_finalizada.id:
                    vals['fecha_finalizado_mnt'] = fields.Datetime.now()
                elif stage_finalizada and new_stage.id != stage_finalizada.id:
                    vals['fecha_finalizado_mnt'] = False
                
                # No salir del historial
                if stage_historial and record.stage_id.id == stage_historial.id and new_stage.id != stage_historial.id:
                    raise UserError("❌ No se puede mover un registro fuera del historial.")
                
                # Solo a historial desde finalizada
                if stage_historial and new_stage.id == stage_historial.id:
                    if record.stage_id.id != stage_finalizada.id:
                        raise UserError("⚠️ Solo los mantenimientos finalizadas pueden archivarse en el historial.")
                
                # No retroceder etapas
                if new_stage and record.stage_id and new_stage.sequence < record.stage_id.sequence:
                    raise UserError("❌ No se puede retroceder un mantenimiento a una etapa anterior.")

        # Escribir los valores
        res = super(HotelMantenimiento, self).write(vals)

        # --- C. ACTUALIZACIÓN DEL ESTADO DE LA HABITACIÓN ---
        # Se realiza una segunda iteración (o se usa self) para aplicar la lógica después de escribir los valores.
        for record in self:
            current_stage_id = vals.get('stage_id', record.stage_id.id)
            
            if stage_en_progreso and current_stage_id == stage_en_progreso.id:
                # EN PROGRESO → Habitación = En Mantenimiento
                if stage_hab_mantenimiento and record.id_habitacion:
                    record.id_habitacion.stage_id = stage_hab_mantenimiento
            
            elif stage_finalizada and current_stage_id == stage_finalizada.id:
                # FINALIZADA → Habitación = Disponible
                if stage_disponible and record.id_habitacion:
                    record.id_habitacion.stage_id = stage_disponible
                    
        return res

    # -----------------------------------------
    # MÉTODOS COMPUTE Y FUNCIONALES
    # Métodos para calcular valores de campos y funcionalidad específica.
    # -----------------------------------------
    
    # Método compute para determinar si el registro está en la etapa de historial.
    @api.depends('stage_id')
    def _compute_is_historial(self):
        """Calcula el valor del campo 'is_historial' basado en la etapa actual."""
        try:
            stage_historial = self.env.ref('gestion_hotelera.stage_mantenimiento_historial')
        except ValueError:
            stage_historial = None
        for record in self:
            record.is_historial = (record.stage_id == stage_historial)

    # Método modelo para expandir las etapas en las vistas Kanban/Pivot/Gráfico.
    @api.model
    def expand_stages(self, stages, domain):
        """Asegura que todas las etapas se muestren en la vista (independientemente de si tienen registros)."""
        stage_ids = stages.sudo()._search([], order=stages._order)
        return stages.browse(stage_ids)

    # -------------------------
    # 3) Progreso según estado (ACTUALIZADO)
    # -------------------------
    @api.depends('stage_id')
    def _compute_progreso(self):
        """
        Asigna porcentaje de progreso según el estado interno de la etapa.
        """
        for rec in self:
            estado = rec.stage_id.estado_interno if rec.stage_id else False
            if estado == 'nuevo':
                rec.progreso = 0
            elif estado == 'en_progreso':
                rec.progreso = 50
            elif estado == 'finalizado':
                rec.progreso = 100
            else:
                rec.progreso = 0
    
    # -------------------------
    # 4) Color/orden Gantt (ACTUALIZADO: Lógica compleja de fecha/estado)
    # -------------------------
    @api.depends('fecha_inicio_mnt', 'stage_id.estado_interno')
    def _compute_color_gantt(self):
        """
        Asigna un código de color numérico para la vista de Gantt basado en:
        1. Estado (Prioridad alta).
        2. Proximidad a la fecha de inicio (solo si el estado es 'nuevo').
        """
        # Se requiere importar timezone dentro de un compute para evitar problemas de dependencia
        from pytz import timezone
        tz_mx = timezone("America/Mexico_City")
        
        for rec in self:
            gantt = 5  # Valor por defecto (color neutro)
            estado = rec.stage_id.estado_interno if rec.stage_id else False
            
            # PRIORIDAD POR ESTADO
            if estado == 'en_progreso':
                gantt = 4
            elif estado == 'finalizado':
                gantt = 10
            elif estado == 'historial':
                gantt = 0
            else:
                # Lógica de fechas (solo para estado nuevo/por defecto)
                if rec.fecha_inicio_mnt:
                    # Convertir fechas a la zona horaria local de México
                    inicio_local = rec.fecha_inicio_mnt.astimezone(tz_mx)
                    ahora_local = fields.Datetime.now().astimezone(tz_mx)
                    # Diferencia en minutos
                    diff_minutes = (inicio_local - ahora_local).total_seconds() / 60
        
                    if inicio_local.date() == ahora_local.date():
                        if 0 <= diff_minutes <= 59:
                            gantt = 1  # Rojo (menos de 1 hora)
                        elif 60 <= diff_minutes <= 119:
                            gantt = 2  # Naranja (entre 1 y 2 horas)
                        elif diff_minutes > 120:
                            gantt = 3  # Amarillo (más de 2 horas)
                        else:
                            gantt = 1  # Retrasado
                    else:
                        gantt = 5  # Otro día (color por defecto)
        
            rec.color = gantt # Asignar el valor calculado al campo 'color'

    # -------------------------
    # 5) Color para kanban (clase CSS) (ACTUALIZADO)
    # -------------------------
    @api.depends('fecha_inicio_mnt', 'stage_id.estado_interno')
    def _compute_color_class(self):
        """
        Calcula una clase CSS (color_class) para la vista Kanban basada en:
        1. El estado (Progreso, Finalizado, Historial).
        2. La proximidad de la 'fecha_inicio_mnt' a la fecha actual (solo si el estado es 'nuevo').
        """
        # Se requiere importar timezone dentro de un compute
        from pytz import timezone
    
        for rec in self:
            if not rec.fecha_inicio_mnt:
                rec.color_class = '4_odooo' # Por defecto si no hay fecha
                continue
    
            estado = rec.stage_id.estado_interno if rec.stage_id else False
            
            # PRIORIDAD POR ESTADO
            if estado == 'en_progreso':
                rec.color_class = '5_azul'
                continue
            elif estado == 'finalizado':
                rec.color_class = '6_verde'
                continue
            elif estado == 'historial':
                rec.color_class = '7_gris'
                continue
                
            # Lógica por fecha (para estados no finalizados)
            tz_mx = timezone("America/Mexico_City")
            inicio_local = rec.fecha_inicio_mnt.astimezone(tz_mx)
            ahora_local = fields.Datetime.now().astimezone(tz_mx)
            diferencia = (inicio_local - ahora_local).total_seconds() / 60
    
            if inicio_local.date() == ahora_local.date():
                if 0 <= diferencia <= 59:
                    rec.color_class = '1_rojo'
                elif 60 <= diferencia <= 119:
                    rec.color_class = '2_naranja'
                elif diferencia > 120:
                    rec.color_class = '3_amarillo'
                else:
                    rec.color_class = '1_rojo' # Retrasado
            else:
                rec.color_class = '4_odooo' # Otro día

    # -------------------------
    # 6) Color list HTML (placeholder para compatibilidad) (NUEVO)
    # -------------------------
    @api.depends('color_class')
    def _compute_color_list_html(self):
        """
        Computa una representación HTML mínima para mostrar un badge de color en vistas de lista,
        basado en la clase de color calculada para Kanban.
        """
        for rec in self:
            # Crea un span con la clase CSS y muestra la clase para debug/visualización
            rec.color_list_html = '<span class="badge %s">%s</span>' % (rec.color_class or '4_odooo', rec.color_class or 'Default')


    # Método compute para generar la cadena de nombres de los responsables.
    @api.depends('empleado_ids')
    def _compute_empleado_nombres(self):
        """Concatena los nombres de todos los empleados asignados en una sola cadena."""
        for rec in self:
            if rec.empleado_ids:
                rec.empleado_nombres = ", ".join(rec.empleado_ids.mapped('name'))
            else:
                rec.empleado_nombres = "Sin responsables"

    # Método compute para generar el texto de la habitación para la vista de Gantt.
    @api.depends('id_habitacion')
    def _compute_campo_habitacion_gantt(self):
        """Formatea el nombre de la habitación para su uso en la etiqueta de la vista Gantt."""
        for record in self:
            if record.id_habitacion:
                record.campo_habitacion_gantt = f"Habitación: {record.id_habitacion.name}"
            else:
                record.campo_habitacion_gantt = "Habitación: N/A"

    # Método compute para generar el texto de los responsables para la vista de Gantt.
    @api.depends('empleado_nombres')
    def _compute_encargado_gantt(self):
        """Formatea la lista de responsables para su uso en la etiqueta de la vista Gantt."""
        for record in self:
            if record.empleado_nombres and record.empleado_nombres != "Sin responsables":
                record.encargado_gantt = f"Responsables: {record.empleado_nombres}"
            else:
                record.encargado_gantt = "Sin responsables"

    # Acción de botón para eliminar permanentemente los registros de historial.
    def eliminar_historial_mnt(self):
        """Busca y elimina todas las órdenes de mantenimiento que se encuentren en la etapa 'Historial'."""
        stage_historial = self.env.ref('gestion_hotelera.stage_mantenimiento_historial', raise_if_not_found=False)
        if not stage_historial:
            raise UserError("❌ No se encontró la etapa Historial.")

        historial = self.search([('stage_id', '=', stage_historial.id)])
        if not historial:
            raise UserError("❌ No hay registros de historial para eliminar.")

        historial.unlink()
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }

    # Función del Cron Job para automatizar el archivado de registros.
    @api.model
    def _automatizar_historial_mnt(self):
        """
        Función programada (Cron Job) que mueve automáticamente registros con etapa 'Finalizado' 
        a la etapa 'Historial' si ha transcurrido un tiempo límite (1 minuto en este caso) desde su finalización.
        """
        _logger.info("Ejecutando acción programada: _automatizar_historial de mantenimiento")
        
        stage_finalizada = self.env.ref('gestion_hotelera.stage_mantenimiento_finalizada', raise_if_not_found=False)
        stage_historial = self.env.ref('gestion_hotelera.stage_mantenimiento_historial', raise_if_not_found=False)

        if not stage_finalizada or not stage_historial:
            _logger.warning("Faltan etapas Finalizada o Historial. No se puede ejecutar el Cron Job.")
            return

        limite_tiempo = fields.Datetime.now() - timedelta(minutes=1)

        mantenimientos_a_mover = self.search([
            ('stage_id', '=', stage_finalizada.id),
            ('fecha_finalizado_mnt', '<=', limite_tiempo)
        ])

        if mantenimientos_a_mover:
            mantenimientos_a_mover.write({'stage_id': stage_historial.id})
            _logger.info(f"Se movieron {len(mantenimientos_a_mover)} registros a Historial.")
        else:
            _logger.info("No se encontraron registros de mantenimiento para mover a Historial.")
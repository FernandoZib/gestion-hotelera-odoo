from odoo import models, fields

class HotelLimpiezaStage(models.Model):
    _name = 'hotel.limpieza.stage'
    _description = 'Etapas de la Limpieza'
    _order = 'sequence, name'

    name = fields.Char(string='Estado', required=True)
    sequence = fields.Integer(string='Secuencia', default=1)
    fold = fields.Boolean(string='Colapsable', default=False)

    # Campo técnico que identifica la lógica del estado
    estado_interno = fields.Selection([
        ('nuevo', 'Nuevo'),
        ('en_progreso', 'En Progreso'),
        ('finalizado', 'Finalizado'),
        ('historial', 'Historial'),
    ], string='Identificador Interno', required=True)
from odoo import models, fields, api
import base64

class TipoHabitacion(models.Model):
    _name = 'hotel.habitacion.tipo'
    _description = 'Tipo de habitación del hotel'

    name = fields.Char(string='Tipo de habitación', required=True)
    notas = fields.Text(string="Notas", copy=False)
    max_personas = fields.Integer(string='Máximo de Personas')
    imagen_ids = fields.One2many('hotel.habitacion.tipo.imagen', 'tipo_habitacion_id', string='Galería de Imágenes')
    imagen_portada = fields.Binary(string='Imagen de Portada', compute='_compute_imagen_portada', store=True)
    
    # Campo temporal para cargar múltiples imágenes
    imagenes_temp = fields.Many2many(
        'ir.attachment',
        'hotel_tipo_habitacion_imagenes_temp_rel',
        'tipo_habitacion_id',
        'attachment_id',
        string='📸 Seleccionar Imágenes',
        help='Selecciona una o varias imágenes. Se guardarán cuando guardes el registro.'
    )
    # Campo computed para mostrar estado de carga
    imagenes_temp_count = fields.Integer(
        string='Imágenes Pendientes',
        compute='_compute_imagenes_temp_count',
        store=False
    )
    
    tiene_imagenes_temp = fields.Boolean(
        string='Tiene Imágenes Temporales',
        compute='_compute_imagenes_temp_count',
        store=False
    )

    @api.depends('imagenes_temp')
    def _compute_imagenes_temp_count(self):
        for record in self:
            record.imagenes_temp_count = len(record.imagenes_temp)
            record.tiene_imagenes_temp = len(record.imagenes_temp) > 0

    @api.depends('imagen_ids.es_portada', 'imagen_ids.imagen_thumbnail')
    def _compute_imagen_portada(self):
        for record in self:
            imagen_portada = record.imagen_ids.filtered(lambda x: x.es_portada)
            if imagen_portada:
                record.imagen_portada = imagen_portada[0].imagen_thumbnail
            elif record.imagen_ids:
                record.imagen_portada = record.imagen_ids[0].imagen_thumbnail
            else:
                record.imagen_portada = False

    def write(self, vals):
        """Sobrescribir write para procesar imágenes temporales"""
        res = super().write(vals)
        
        # Procesar imágenes temporales cuando se guarda
        if 'imagenes_temp' in vals or self.imagenes_temp:
            self._process_temp_images()
        
        return res

    @api.model_create_multi
    def create(self, vals_list):
        """Sobrescribir create para procesar imágenes temporales"""
        records = super().create(vals_list)
        
        for record in records:
            if record.imagenes_temp:
                record._process_temp_images()
        
        return records

    def _process_temp_images(self):
        """Procesa las imágenes temporales y las convierte en registros permanentes"""
        for record in self:
            if record.imagenes_temp:
                for attachment in record.imagenes_temp:
                    # Crear el registro de imagen permanente
                    self.env['hotel.habitacion.tipo.imagen'].create({
                        'name': attachment.name or 'Imagen',
                        'imagen': attachment.datas,
                        'tipo_habitacion_id': record.id,
                    })
                
                # Limpiar las imágenes temporales
                record.imagenes_temp = [(5, 0, 0)]


class TipoHabitacionImagen(models.Model):
    _name = 'hotel.habitacion.tipo.imagen'
    _description = 'Imágenes del tipo de habitación'
    _order = 'es_portada desc, id desc'

    name = fields.Char(string='Nombre del Archivo', default='Imagen', required=True)
    imagen = fields.Image(
        string='Imagen',
        required=True,
        max_width=1920,
        max_height=1920,
        attachment=True
    )
    imagen_thumbnail = fields.Image(
        string='Miniatura',
        related='imagen',
        max_width=300,
        max_height=300,
        store=True
    )
    tipo_habitacion_id = fields.Many2one(
        'hotel.habitacion.tipo',
        string='Tipo de Habitación',
        required=True,
        ondelete='cascade',
        index=True
    )
    es_portada = fields.Boolean(string='Portada', default=False, index=True)

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        
        # NUEVO: Hacer attachments públicos después de crear
        for record in records:
            record._make_attachments_public()
        
        # Si alguna imagen se marca como portada, actualizamos
        portadas = records.filtered(lambda x: x.es_portada)
        if portadas:
            for portada in portadas:
                portada._set_as_portada()
        
        return records

    def write(self, vals):
        # Si se intenta activar la portada, verificar primero
        if 'es_portada' in vals and vals.get('es_portada'):
            for record in self:
                # Desactivar otras portadas ANTES de activar esta
                otras_imagenes = self.search([
                    ('tipo_habitacion_id', '=', record.tipo_habitacion_id.id),
                    ('id', '!=', record.id),
                    ('es_portada', '=', True)
                ])
                if otras_imagenes:
                    otras_imagenes.write({'es_portada': False})
        
        res = super().write(vals)
        
        # NUEVO: Si se actualiza la imagen, hacer attachment público
        if 'imagen' in vals:
            self._make_attachments_public()
        
        return res

    def _make_attachments_public(self):
        """
        NUEVO MÉTODO: Hacer que los attachments de las imágenes sean públicos
        para que se puedan ver sin estar logueado
        """
        Attachment = self.env['ir.attachment'].sudo()
        
        for record in self:
            # Buscar attachments relacionados con este registro
            attachments = Attachment.search([
                ('res_model', '=', self._name),
                ('res_id', '=', record.id),
                ('res_field', 'in', ['imagen', 'imagen_thumbnail'])
            ])
            
            # Hacer públicos
            if attachments:
                attachments.write({'public': True})
                print(f"✅ {len(attachments)} attachment(s) de imagen {record.id} ahora son públicos")

    def _set_as_portada(self):
        """Asegura que solo una imagen sea portada por tipo de habitación"""
        self.ensure_one()
        if self.es_portada:
            # Quitar portada de otras imágenes del mismo tipo
            otras_imagenes = self.search([
                ('tipo_habitacion_id', '=', self.tipo_habitacion_id.id),
                ('id', '!=', self.id),
                ('es_portada', '=', True)
            ])
            if otras_imagenes:
                otras_imagenes.write({'es_portada': False})

    def action_delete(self):
        """Acción para eliminar la imagen"""
        self.unlink()
        return {'type': 'ir.actions.act_window_close'}
    
    def action_make_all_public(self):
        """
        NUEVO MÉTODO: Acción manual para hacer públicas todas las imágenes existentes
        Útil si ya tienes imágenes cargadas antes de este cambio
        """
        all_images = self.search([])
        for image in all_images:
            image._make_attachments_public()
        
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Éxito',
                'message': f'{len(all_images)} imágenes ahora son públicas',
                'type': 'success',
                'sticky': False,
            }
        }
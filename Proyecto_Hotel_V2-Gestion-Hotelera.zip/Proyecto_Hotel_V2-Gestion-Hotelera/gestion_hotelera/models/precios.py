from odoo import models, fields, api

class HotelPrecio(models.Model):
    _name = 'hotel.precio'
    _description = 'Precios de Habitaciones'
    _rec_name = 'id_precio'
    _order = 'id_precio desc'

    id_precio = fields.Char(
        string='Código Precio',
        readonly=True,
        copy=False,
        default='PREC'
    )

    precio_noche = fields.Monetary(
        string='Precio por Noche',
        currency_field='currency_id'
    )

    id_habitacion = fields.Many2one(
        'hotel.habitacion',
        string='Habitación',
        required=True
    )

    id_tarifa = fields.Many2one(
        'hotel.tarifa',
        string='Tarifa',
        required=False
    )

    currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        default=lambda self: self.env.company.currency_id
    )

    tarifa_precio_temporada = fields.Monetary(
            string="Precio de temporada",
            related='id_tarifa.precio_temporada',
            readonly=True
    ) 

    tarifa_fecha_inicio = fields.Date(
            string="Fecha de inicio",
            related='id_tarifa.fecha_inicio',
            readonly=True
    ) 

    tarifa_fecha_fin = fields.Date(
            string="Fecha de fin",
            related='id_tarifa.fecha_fin',
            readonly=True
    ) 
    
    @api.model_create_multi
    def create(self, vals_list):
        """Asignar secuencia automáticamente al crear el registro."""
        for vals in vals_list:
            if not vals.get('id_precio') or vals['id_precio'] == 'New':
                vals['id_precio'] = self.env['ir.sequence'].next_by_code('hotel.precio.seq') or 'Nuevo'
        return super(HotelPrecio, self).create(vals_list)
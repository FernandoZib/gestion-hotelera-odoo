from odoo import models, fields, api
from markupsafe import Markup
from datetime import datetime

class HotelTarifa(models.Model):
    _name = 'hotel.tarifa'
    _description = 'Tarifas del Hotel'
    _rec_name = 'name'
    _order = 'name desc'
    _inherit = 'mail.thread', 'mail.activity.mixin'

    #campo de secuencia
    '''id_tarifa = fields.Char(
        string='Código Tarifa',
        readonly=True,
        copy=False,
        default='TAR'
    )'''

    name = fields.Char(
        string='Nombre de la Temporada',
        required=True
    )

    precio_temporada = fields.Monetary(
        string='Precio de Temporada',
        required=True,
        currency_field='currency_id'
    )
    
    currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        default=lambda self: self.env.company.currency_id
    )

    fecha_inicio = fields.Date(
        string='Fecha de Inicio',
        required=True
    )

    fecha_fin = fields.Date(
        string='Fecha de Fin',
        required=True
    )

    #secuencia de tarifa
    '''@api.model_create_multi
    def create(self, vals_list):
        """Asignar secuencia automáticamente al crear el registro."""
        for vals in vals_list:
            #if not vals.get('id_tarifa'):
            if vals.get('id_tarifa', 'TAR') in (False, 'TAR', 'New', 'Nuevo'):
                vals['id_tarifa'] = self.env['ir.sequence'].next_by_code('hotel.tarifa.seq') or 'Nuevo'
        return super(HotelTarifa, self).create(vals_list)'''

    def write(self, vals):
        # Guardar valores anteriores antes de actualizar
        for record in self:
            old_values = {
                    'name': record.name,
                    'precio_temporada': f"{record.precio_temporada:,.2f}",
                    'currency_id': record.currency_id.name if record.currency_id else False,
                    'currency_symbol': record.currency_id.symbol if record.currency_id else False,
                    'fecha_inicio': record.fecha_inicio,
                    'fecha_fin': record.fecha_fin,
            }

            # Ejecutar el write original
            result = super().write(vals)

            '''if 'currency_id' in vals:
                nueva_moneda = self.env['res.currency'].browse(vals['currency_id']).name if vals['currency_id'] else 'Ninguno'
                cambios.append(f"Moneda cambió de '{old_values['currency_id']}' a '{nueva_moneda}'")'''
                
            # Construir mensaje personalizado si hubo cambios
            cambios = []

            if 'name' in vals:
                cambios.append(f"Nombre de Temporada: <strong style='color: #939393;'>{old_values['name']}</strong> -> <strong style='color: #038F00;'>{vals['name']}</strong>")
            else:
                cambios.append(f"Nombre de temporada: <strong>{old_values['name']}</strong>")
            
            if 'precio_temporada' in vals:
                precio_temp_nuevo = f"{vals['precio_temporada']:,.2f}"
                if 'currency_id' in vals:
                    simbolo = '' if not vals.get('currency_id') else self.env['res.currency'].browse(vals['currency_id']).symbol
                    cambios.append(f"Precio de temporada: <strong style='color: #939393;'>{simbolo} {precio_temp_nuevo}</strong> -> <strong style='color: #038F00;'>{simbolo} {precio_temp_nuevo}</strong>")
                else:
                    simbolo = '' if not old_values['currency_id'] else old_values['currency_symbol']
                    cambios.append(f"Precio de temporada: <strong style='color: #939393;'>{simbolo} {old_values['precio_temporada']}</strong> -> <strong style='color: #038F00;'>{simbolo} {precio_temp_nuevo}</strong>")
            else:
                if 'currency_id' in vals:
                    simbolo = '' if not vals.get('currency_id') else self.env['res.currency'].browse(vals['currency_id']).symbol
                    cambios.append(f"Precio de temporada: <strong>{simbolo} {old_values['precio_temporada']}</strong>")
                    
            if 'currency_id' in vals: #and old_values['currency_id'] != vals['currency_id']:
                nueva_moneda = self.env['res.currency'].browse(vals['currency_id']).name
                cambios.append(f"Moneda: <strong style='color: #939393;'>{old_values['currency_id']}</strong> -> <strong style='color: #038F00;'>{nueva_moneda}</strong>")
            else:
                cambios.append(f"Moneda: <strong>{old_values['currency_id']}</strong>")

            if 'fecha_inicio' in vals:
                fecha_antigua = old_values['fecha_inicio'].strftime('%d-%m-%Y')
                fecha_nueva = fields.Date.from_string(vals['fecha_inicio']).strftime('%d-%m-%Y')
                cambios.append(f"Fecha de inicio: <strong style='color: #939393;'>{fecha_antigua}</strong> -> <strong style='color: #038F00;'>{fecha_nueva}</strong>")
            else:
                fecha_antigua = old_values['fecha_inicio'].strftime('%d-%m-%Y')
                cambios.append(f"Fecha de inicio: <strong>{fecha_antigua}</strong>")

            if 'fecha_fin' in vals:
                fecha_antigua = old_values['fecha_fin'].strftime('%d-%m-%Y')
                fecha_nueva = fields.Date.from_string(vals['fecha_fin']).strftime('%d-%m-%Y')
                cambios.append(f"Fecha de fin: <strong style='color: #939393;'>{fecha_antigua}</strong> -> <strong style='color: #038F00;'>{fecha_nueva}</strong>")
            else:
                fecha_antigua = old_values['fecha_fin'].strftime('%d-%m-%Y')
                cambios.append(f"Fecha de fin: <strong>{fecha_antigua}</strong>")

            # Publicar mensaje si hay cambios
            if cambios:
                mensaje = Markup(f"""
                    <p><strong>Información actualizada:</strong></p>
                    <ul>
                        {''.join([f'<li>{cambio}</li>' for cambio in cambios])}
                    </ul>
                """)
                record.message_post(
                    body=mensaje,
                    subject='Registro actualizado',
                    message_type='notification',
                    subtype_xmlid='mail.mt_note'
                )
            
        return result

from odoo import models, fields

class AccountMove(models.Model):
    _inherit = 'account.move'

    reserva_id = fields.Many2one(
        'hotel.reserva',
        string='Reserva',
        help="Reserva asociada a esta factura."
    )

    #-----------accion de smartbutton-----------
    def action_open_reserva(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'hotel.reserva',
            'view_mode': 'form',
            'res_id': self.reserva_id.id,
            'target': 'current',
        }


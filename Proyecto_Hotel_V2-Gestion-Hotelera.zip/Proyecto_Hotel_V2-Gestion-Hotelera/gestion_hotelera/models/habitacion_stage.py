from odoo import models, fields, api

class HabitacionStage(models.Model):
    _name = 'hotel.habitacion.stage'
    _description = 'Etapas de la Habitación'
    _order = 'sequence, name'

    name = fields.Char(string='Estado', required=True)
    sequence = fields.Integer(string='Secuencia', default=1)
    fold = fields.Boolean(string='Colapsable', default=False)
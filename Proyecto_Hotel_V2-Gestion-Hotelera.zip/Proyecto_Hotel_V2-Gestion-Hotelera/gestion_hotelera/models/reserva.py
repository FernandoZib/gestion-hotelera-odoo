from odoo import models, fields, api, exceptions, _
from odoo.exceptions import RedirectWarning # <-- ¡AÑADIR ESTO!
from datetime import datetime, timedelta, time


class Reserva(models.Model):
    _name = 'hotel.reserva'
    _description = 'Reservas de Habitaciones'
    _rec_name = 'display_name'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    # ============================================================
    # CAMPOS PRINCIPALES
    # ============================================================
    tipo_habitacion_id = fields.Many2one(
        'hotel.habitacion.tipo',
        string='Tipo de Habitación',
        required=True,
        tracking=True,
    )

    id_cliente = fields.Many2one(
        'res.partner',
        string='Cliente',
        required=True,
        tracking=True,
        help='Cliente asociado a la reserva',        
    )

    habitacion_id = fields.Many2one(
        'hotel.habitacion',
        string='Habitación',
        required=True,
        domain="[('tipo_habitacion_id', '=', tipo_habitacion_id)]",
    )

    precio_id = fields.Many2one(
        'hotel.precio',
        string='Precio',
        help='Precio seleccionado (si se quiere forzar uno).'
    )

    factura_id = fields.Many2one(
        'account.move',
        string="Factura",
        readonly=True
    )

    fecha_reserva = fields.Date(
        string='Fecha de Reserva',
        required=True,
        readonly=True,
        default=fields.Date.context_today
    )
    fecha_check_in = fields.Datetime(string='Fecha de Check-In', required=True)
    fecha_check_out = fields.Datetime(string='Fecha de Check-Out', required=True)

    monto_total_reserva = fields.Float(
        string='Monto Total de la Reserva',
        compute='_compute_monto_total_reserva',
        store=True
    )

    stage_id = fields.Many2one(
        'hotel.reserva.stage',
        string='Estado de la Reserva',
        required=True,
        tracking=True,
        group_expand='expand_stages',
        default=lambda self: self.env.ref('gestion_hotelera.pendiente_pago', raise_if_not_found=False)
    )

    factura_estado_pago = fields.Selection(
        string="Estado del Pago",
        related='factura_id.status_in_payment',
        readonly=True
    )

    notas = fields.Text(string='Notas')

    numero_reserva = fields.Char(
        string='Número de Reserva',
        readonly=True,
        copy=False,
        default='RSV---'
    )

    # Nuevo campo para almacenar el motivo de cancelación
    motivo_cancelacion = fields.Selection(
        [
            ('cambio_planes', 'Cambio de planes'),
            ('problemas_personales', 'Problemas personales o dificultades para llegar al hotel'),
            ('reserva_duplicada', 'Reserva duplicada'),
            ('inconformidad_checkin', 'Inconformidad antes del check-in'),
            ('incumplimiento_pago', 'Incumplimiento de pago'),
            ('no_show', 'No-show'),
            ('info_falsa', 'Información falsa o incompleta'),
            ('violacion_politicas', 'Violación de políticas o conducta inapropiada del huésped'),
            ('problemas_internos', 'Problemas internos del hotel'),
        ],
        string='Motivo de Cancelación',
        tracking=True,
        readonly=True,  # Solo se llenará a través del wizard
        copy=False,
    )

    display_name = fields.Char(
        string='Nombre Visible',
        compute='_compute_display_name',
        store=True,
        compute_sudo=True,
        readonly=True,
    )
    readonly_tipo_habitacion = fields.Boolean(
    string="Readonly Tipo Habitación",
    compute='_compute_readonly_tipo_habitacion'
    )

    # Nuevo campo: Almacena las IDs de las habitaciones no disponibles en las fechas seleccionadas
    habitaciones_reservadas_ids = fields.Many2many(
        'hotel.habitacion',
        compute='_compute_habitaciones_reservadas',
        store=False, # No se almacena en BD, se calcula al vuelo
        string="Habitaciones Ocupadas (Calculado)"
    )

    @api.depends('fecha_check_in', 'fecha_check_out')
    def _compute_habitaciones_reservadas(self):
        """
        Calcula qué habitaciones están ocupadas en el rango de fechas
        actualmente seleccionado en el formulario.
        """
        # IDs de las etapas que NO BLOQUEAN la habitación
        # (Se usan las referencias de la BD para máxima compatibilidad)
        stage_cancelada = self.env.ref('gestion_hotelera.cancelada', raise_if_not_found=False).id or 0
        stage_finalizada = self.env.ref('gestion_hotelera.finalizada_checkout', raise_if_not_found=False).id or 0
        stage_historial = self.env.ref('gestion_hotelera.historial', raise_if_not_found=False).id or 0
        
        stages_no_bloquean = [stage_cancelada, stage_finalizada, stage_historial]
        
        for record in self:
            # Si no hay fechas definidas, el filtro es irrelevante, no bloqueamos ninguna.
            if not record.fecha_check_in or not record.fecha_check_out or record.fecha_check_in >= record.fecha_check_out:
                record.habitaciones_reservadas_ids = False
                continue

            # Dominio de Solapamiento
            overlap_domain = [
                ('id', '!=', record.id), # Excluye la reserva actual (si existe)
                ('stage_id', 'not in', stages_no_bloquean), # Solo reservas activas
                # Criterio de Solapamiento:
                # La reserva existente comienza antes de que la nueva finalice
                ('fecha_check_in', '<', record.fecha_check_out),
                # La reserva existente finaliza después de que la nueva comienza
                ('fecha_check_out', '>', record.fecha_check_in),
            ]

            # 1. Buscar las reservas solapadas
            reservas_solapadas = self.search(overlap_domain)

            # 2. Obtener los IDs de las habitaciones de esas reservas
            habitaciones_ocupadas = reservas_solapadas.mapped('habitacion_id')

            # 3. Asignar el recordset de habitaciones al campo Many2many
            record.habitaciones_reservadas_ids = habitaciones_ocupadas   



    # ============================================================
    # COLOR DINÁMICO PARA KANBAN
    # ============================================================
    color_class = fields.Char(
        string="Clase de Color Kanban",
        compute="_compute_color_class",
        store=False
    )
    
    @api.depends("fecha_check_in", "fecha_check_out", "stage_id")
    def _compute_color_class(self):
        now = fields.Datetime.now()
    
        for rec in self:
            # Seguridad: valor por defecto
            rec.color_class = "gris"
    
            # Si no existe fecha checkin ni checkout, queda gris
            if not rec.fecha_check_in and not rec.fecha_check_out:
                continue

            # 3 SI está en "Finalizado, Historial o Cancelada"
            if  rec.stage_id.name == "Finalizada (Check-Out)":                 
                continue

            if rec.stage_id.name == "Cancelada":               
                continue

            if rec.stage_id.name == "Historial":                 
                continue
    
            # 1️⃣ SI NO está en "Confirmada (Check-In)" → usar check-in
            if rec.stage_id and rec.stage_id.name != "Confirmada (Check-In)":
                if rec.fecha_check_in:
                    delta = rec.fecha_check_in - now
                    horas = delta.total_seconds() / 3600
    
                    if horas < 0:
                        rec.color_class = "rojo"
                    elif horas <= 6:
                        rec.color_class = "naranja"
                    elif horas <= 24:
                        rec.color_class = "amarillo"
                    elif horas <= 72:
                        rec.color_class = "azul"
                    else:
                        rec.color_class = "verde"
                else:
                    rec.color_class = "gris"
                continue
    
            # 2️⃣ SI está en "Confirmada (Check-In)" → usar checkout
            if rec.stage_id and rec.stage_id.name == "Confirmada (Check-In)":
                if rec.fecha_check_out:
                    delta = rec.fecha_check_out - now
                    horas = delta.total_seconds() / 3600
    
                    if horas < 0:
                        rec.color_class = "rojo"
                    elif horas <= 6:
                        rec.color_class = "naranja"
                    elif horas <= 24:
                        rec.color_class = "amarillo"
                    elif horas <= 72:
                        rec.color_class = "azul"
                    else:
                        rec.color_class = "verde"
                else:
                    rec.color_class = "gris"
                continue


    @api.depends('fecha_check_in', 'fecha_check_out')
    def _compute_readonly_tipo_habitacion(self):
        for rec in self:
            rec.readonly_tipo_habitacion = not (rec.fecha_check_in and rec.fecha_check_out)
    
    # ============================================================
    # ONCHANGE: filtrar habitaciones por tipo (devuelve domain + limpia)
    # ============================================================
    @api.onchange('tipo_habitacion_id')
    def _onchange_tipo_habitacion(self):
        self.habitacion_id = False
    # ============================================================
    # ONCHANGE: filtrar precios por habitación y fechas (domain dinámico)
    # ============================================================
    @api.onchange('habitacion_id', 'fecha_check_in', 'fecha_check_out')
    def _onchange_habitacion_o_fechas(self):
        """Domain dinámico para precio_id: precios para la habitación que
        tengan tarifa solapante con el rango o precios sin tarifa."""
        domain = {}
        precio_model = self.env['hotel.precio']

        if not self.habitacion_id:
            domain['precio_id'] = []
            return {'domain': domain}

        # Todos los precios de la habitación
        precio_ids = precio_model.search([('id_habitacion', '=', self.habitacion_id.id)]).ids

        # Si hay fechas válidas filtramos por solapamiento con la tarifa
        if self.fecha_check_in and self.fecha_check_out and self.fecha_check_in < self.fecha_check_out:
            fecha_ini = fields.Datetime.to_datetime(self.fecha_check_in).date()
            fecha_fin = fields.Datetime.to_datetime(self.fecha_check_out).date()

            # precios cuyo id_tarifa se solapa con el rango (fecha_inicio <= fecha_fin_reserva AND fecha_fin >= fecha_ini_reserva)
            precios_tarifa = precio_model.search([
                ('id_habitacion', '=', self.habitacion_id.id),
                ('id_tarifa.fecha_inicio', '<=', fecha_fin),
                ('id_tarifa.fecha_fin', '>=', fecha_ini),
            ]).ids

            # precios sin tarifa (fallback)
            precios_sin_tarifa = precio_model.search([
                ('id_habitacion', '=', self.habitacion_id.id),
                ('id_tarifa', '=', False),
            ]).ids

            precio_ids = sorted(set(precios_tarifa + precios_sin_tarifa))

            # Si no se encontró nada, devolvemos todos los precios de la habitación como último recurso
            if not precio_ids:
                precio_ids = precio_model.search([('id_habitacion', '=', self.habitacion_id.id)]).ids
        else:
            # sin fechas: mostramos todos los precios de la habitación
            precio_ids = precio_model.search([('id_habitacion', '=', self.habitacion_id.id)]).ids

        domain['precio_id'] = [('id', 'in', precio_ids)] if precio_ids else []
        return {'domain': domain}

    # ============================================================
    # Compute display_name
    # ============================================================
    @api.depends('numero_reserva', 'id_cliente', 'habitacion_id')
    def _compute_display_name(self):
        for rec in self:
            name_parts = []
            if rec.numero_reserva:
                name_parts.append(rec.numero_reserva)
            if rec.id_cliente:
                name_parts.append(rec.id_cliente.name)
            if rec.habitacion_id:
                nombre_h = getattr(rec.habitacion_id, 'name', False) or getattr(rec.habitacion_id, 'numero_habitacion', False) or str(rec.habitacion_id.id)
                name_parts.append(nombre_h)
            rec.display_name = ' / '.join(name_parts) if name_parts else 'RSV-'

    # ============================================================
    # VALIDACIONES: fechas y disponibilidad (basado SOLO en reservas)
    # ============================================================
    @api.constrains('fecha_check_in', 'fecha_check_out', 'habitacion_id')
    def _check_fechas_y_disponibilidad(self):
        for rec in self:
            if not rec.habitacion_id or not rec.fecha_check_in or not rec.fecha_check_out:
                continue

            if rec.fecha_check_in >= rec.fecha_check_out:
                raise exceptions.ValidationError(_("La fecha de check-in debe ser anterior a la de check-out."))

            # Buscamos reservas que se solapen en la misma habitación (excluyendo esta reserva)
            # Etapas que sí deben bloquear disponibilidad
            stage_cancelada = self.env.ref('gestion_hotelera.cancelada', raise_if_not_found=False)
            stage_finalizada = self.env.ref('gestion_hotelera.finalizada_checkout', raise_if_not_found=False)
            stage_historial = self.env.ref('gestion_hotelera.historial', raise_if_not_found=False)
            
            otras = self.search([
                ('habitacion_id', '=', rec.habitacion_id.id),
                ('id', '!=', rec.id),
                # EXCLUIR reservas canceladas, finalizadas o de historial
                ('stage_id', 'not in', [
                    stage_cancelada.id if stage_cancelada else 0,
                    stage_finalizada.id if stage_finalizada else 0,
                    stage_historial.id if stage_historial else 0,
                ])
            ])


            for r in otras:
                if r.fecha_check_in and r.fecha_check_out:
                    # Si existe solapamiento -> error
                    if not (rec.fecha_check_in >= r.fecha_check_out or rec.fecha_check_out <= r.fecha_check_in):
                        raise exceptions.ValidationError(
                            _("⚠️ La habitación '%s' ya está reservada entre %s y %s.")
                            % (
                                getattr(rec.habitacion_id, 'name', rec.habitacion_id.id),
                                r.fecha_check_in.strftime('%d/%m/%Y %H:%M'),
                                r.fecha_check_out.strftime('%d/%m/%Y %H:%M'),
                            )
                        )


    @api.onchange('fecha_check_in', 'fecha_check_out', 'habitacion_id')
    def _onchange_fechas_y_disponibilidad(self):
    
        if not self.habitacion_id or not self.fecha_check_in or not self.fecha_check_out:
            return
    
        # Validación simple: check-in < check-out
        if self.fecha_check_in >= self.fecha_check_out:
            return {
                'warning': {
                    'title': "Fechas inválidas",
                    'message': "La fecha de check-in debe ser anterior a la de check-out."
                }
            }
    
        # --- ⚠️ ESTE search SÍ funciona correctamente en onchange ---
        # Se filtran solo rangos que se solapan, sin traer tu mismo registro aunque exista en la BD
        solapadas = self.env['hotel.reserva'].search([
            ('habitacion_id', '=', self.habitacion_id.id),
            ('id', '!=', self._origin.id),     # <--- ESTA ES LA CLAVE
            ('fecha_check_in', '<', self.fecha_check_out),
            ('fecha_check_out', '>', self.fecha_check_in),
            ('stage_id', 'not in', [
                self.env.ref('gestion_hotelera.cancelada', raise_if_not_found=False).id or 0,
                self.env.ref('gestion_hotelera.finalizada_checkout', raise_if_not_found=False).id or 0,
                self.env.ref('gestion_hotelera.historial', raise_if_not_found=False).id or 0,
            ]),
        ])
    
        if solapadas:
            r = solapadas[0]
            return {
                'warning': {
                    'title': "Habitación ocupada",
                    'message': f"La habitación ya está reservada entre {r.fecha_check_in} y {r.fecha_check_out}."
                }
            }



    # ============================================================
    # 🔹 CÁLCULO DEL MONTO TOTAL DE LA RESERVA
    # ============================================================
    
    @api.depends('fecha_check_in', 'fecha_check_out', 'habitacion_id')
    def _compute_monto_total_reserva(self):
        Precio = self.env['hotel.precio']
        Tarifa = self.env['hotel.tarifa']
    
        for rec in self:
            rec.monto_total_reserva = 0.0
    
            if not rec.habitacion_id or not rec.fecha_check_in or not rec.fecha_check_out:
                continue
            if rec.fecha_check_in >= rec.fecha_check_out:
                continue
    
            # ============================================================
            # 1) Obtener el precio principal de la habitación
            # ============================================================
            precio_reg = Precio.search([
                ('id_habitacion', '=', rec.habitacion_id.id)
            ], limit=1)
    
            if not precio_reg:
                raise exceptions.UserError(
                    "La habitación seleccionada no tiene precio asignado."
                )
    
            precio_noche = precio_reg.precio_noche
    
            # ============================================================
            # 2) Calcular noches
            # ============================================================
            fecha_ini = rec.fecha_check_in.date()
            fecha_fin = rec.fecha_check_out.date()
            noches_totales = (fecha_fin - fecha_ini).days
    
            if noches_totales <= 0:
                continue
    
            # ============================================================
            # 3) Buscar tarifas VINCULADAS A ESTA HABITACIÓN
            #    (mediante precios)
            # ============================================================
            precios_habitacion = Precio.search([
                ('id_habitacion', '=', rec.habitacion_id.id),
                ('id_tarifa', '!=', False)
            ])
    
            tarifas_ids = precios_habitacion.mapped('id_tarifa').ids
    
            tarifas = Tarifa.search([
                ('id', 'in', tarifas_ids),
                ('fecha_inicio', '<=', fecha_fin),
                ('fecha_fin', '>=', fecha_ini)
            ])
    
            total = precio_noche * noches_totales
    
            if not tarifas:
                # No aplicar tarifas
                rec.monto_total_reserva = total
                continue
    
            # ============================================================
            # 4) Determinar las tarifas que aplican por cada noche
            # ============================================================
            tarifas_usadas = set()
    
            for i in range(noches_totales):
                dia_actual = fecha_ini + timedelta(days=i)
    
                tarifa_dia = tarifas.filtered(
                    lambda t: t.fecha_inicio <= dia_actual <= t.fecha_fin
                )
    
                if tarifa_dia:
                    tarifas_usadas.add(tarifa_dia[0].id)
    
            # ============================================================
            # 5) Sumar una sola vez cada tarifa usada
            # ============================================================
            for tarifa_id in tarifas_usadas:
                tarifa = Tarifa.browse(tarifa_id)
                total += tarifa.precio_temporada
    
            rec.monto_total_reserva = total


    # ============================================================
    # Create: asignar secuencia y display_name
    # ============================================================
    @api.model_create_multi
    def create(self, vals_list):
        sequence = self.env.ref('gestion_hotelera.seq_reserva_codigo', raise_if_not_found=False)
        records = super().create(vals_list)

        for record in records:
            # asignar numero_reserva si no existe
            if not record.numero_reserva or record.numero_reserva == 'RSV---':
                try:
                    if sequence:
                        record.numero_reserva = sequence.next_by_id()
                    else:
                        record.numero_reserva = f"RSV{record.id:03d}"
                except Exception:
                    record.numero_reserva = f"RSV{record.id:03d}"

            record.display_name = f"{record.numero_reserva} - {getattr(record.habitacion_id, 'name', '')}"
        return records

    @api.model
    def expand_stages(self, stages, domain):
        stage_ids = stages.sudo()._search([], order=stages._order)
        return stages.browse(stage_ids)

    # ===========================================================
    # ELIMINAR LIMPIEZAS RELACIONADAS
    # ===========================================================
    def _eliminar_limpiezas_relacionadas(self):
        observaciones_borrar = [
            'Limpieza de Check-In',
            'Limpieza diaria',
            'Limpieza de Check-Out'
        ]

        for reserva in self:
            if not reserva.habitacion_id or not reserva.fecha_check_in or not reserva.fecha_check_out:
                continue

            fecha_in = reserva.fecha_check_in.date()
            fecha_out = reserva.fecha_check_out.date()

            limpieza_model = reserva.env['hotel.limpieza']

            posibles = limpieza_model.search([
                ('habitacion_id', '=', reserva.habitacion_id.id),
                ('observaciones', 'in', observaciones_borrar),
            ])

            to_unlink = posibles.filtered(lambda l: l.fecha_inicio and fecha_in <= l.fecha_inicio.date() <= fecha_out)

            if not to_unlink:
                continue

            try:
                to_unlink.unlink()
            except Exception as e:
                reserva.env['ir.logging'].create({
                    'name': 'gestion_hotelera: eliminar limpiezas',
                    'type': 'server',
                    'dbname': reserva._cr.dbname,
                    'level': 'ERROR',
                    'message': f'Error en batch para reserva {reserva.id}: {e}',
                    'path': 'gestion_hotelera/reserva.py',
                })
                for l in to_unlink:
                    try:
                        l.unlink()
                    except Exception:
                        pass

    # ============================================================
    # WRITE (acciones por etapas) - CORRECCIÓN PARA EL WIZARD
    # ============================================================
    def write(self, vals):
        # ... (Tus referencias de stage aquí) ...
        historial_stage = self.env.ref('gestion_hotelera.historial', raise_if_not_found=False)
        cancelada_stage = self.env.ref('gestion_hotelera.cancelada', raise_if_not_found=False)
        finalizada_stage = self.env.ref('gestion_hotelera.finalizada_checkout', raise_if_not_found=False)
        pendiente_stage = self.env.ref('gestion_hotelera.pendiente_pago', raise_if_not_found=False)
        confirmada_stage = self.env.ref('gestion_hotelera.confirmada_checkin', raise_if_not_found=False)
        reservada_stage = self.env.ref('gestion_hotelera.reservada', raise_if_not_found=False)

    # ⚠️ LÓGICA DE INTERCEPTACIÓN PARA CANCELACIÓN
        if 'stage_id' in vals and cancelada_stage and vals['stage_id'] == cancelada_stage.id:
            if not self.env.context.get('skip_cancel_wizard'):
                # 📢 La CLAVE es lanzar RedirectWarning con la acción
                action = self.action_open_cancel_wizard()
                
                # 💡 CORRECCIÓN CRÍTICA: Inyectar el ID de la reserva en el contexto de la acción
                if self.ids:
                    # self.id es seguro porque se está intentando escribir en un registro.
                    action['context'] = {'default_reserva_id': self.id} 
                
                raise RedirectWarning( # o RedirectWarning si la importaste directamente
                    _('Debe especificar un motivo de cancelación.'), 
                    action, 
                    _('Abrir formulario de cancelación')
                )
            # Si venimos del wizard (skip_cancel_wizard está presente), eliminamos la bandera
            self = self.with_context(skip_cancel_wizard=False)

        # ... (Tus Validaciones de permisos/estados originales) ...
        for record in self:
            if pendiente_stage and record.stage_id != pendiente_stage:
                allowed = {'stage_id', 'active', 'factura_id', 'factura_estado_pago', 'notas'}
                if any(k not in allowed for k in vals.keys()):
                    raise exceptions.UserError(_("❌ Solo puedes editar la reserva mientras esté en 'Pendiente'."))
            # ... (Resto de tus validaciones) ...
            if historial_stage and record.stage_id == historial_stage:
                if not ('active' in vals and vals['active'] is False):
                    raise exceptions.UserError(_("❌ No puedes modificar una reserva en 'Historial'."))

            if 'stage_id' in vals:
                nuevo_stage = self.env['hotel.reserva.stage'].browse(vals['stage_id'])
                if nuevo_stage and record.stage_id and nuevo_stage.sequence < record.stage_id.sequence:
                    raise exceptions.UserError(_("⚠️ No puedes regresar una reserva a una etapa anterior."))


        # Ejecución de la escritura en la base de datos
        res = super().write(vals)

        # ... (Tus Acciones post-escritura originales) ...
        if 'stage_id' in vals:
            for reserva in self:
                if cancelada_stage and reserva.stage_id == cancelada_stage:
                    reserva._eliminar_limpiezas_relacionadas()

                if reservada_stage and reserva.stage_id == reservada_stage:
                    if reserva.fecha_check_in:
                        reserva._crear_limpieza_automatica('checkin', reserva.fecha_check_in)

                elif confirmada_stage and reserva.stage_id == confirmada_stage:
                    stage_ocupada = self.env.ref('gestion_hotelera.stage_ocupada', raise_if_not_found=False)
                    if stage_ocupada and reserva.habitacion_id:
                        reserva.habitacion_id.stage_id = stage_ocupada.id
                    reserva._crear_limpiezas_diarias()

                elif finalizada_stage and reserva.stage_id == finalizada_stage:
                    if reserva.fecha_check_out:
                        reserva._crear_limpieza_automatica('checkout', reserva.fecha_check_out)

        return res

    # ============================================================
    # Acción para abrir el Wizard de Cancelación
    # ============================================================
    def action_open_cancel_wizard(self):
        self.ensure_one()
        # Devuelve la acción de ventana que definiste en el XML
        return self.env.ref('gestion_hotelera.action_hotel_reserva_cancel_wizard').read()[0]

    # ============================================================
    # UNLINK
    # ============================================================
    def unlink(self):
        self._eliminar_limpiezas_relacionadas()
        return super().unlink()

    # ============================================================
    # Método utilitario: fechas ocupadas
    # ============================================================
    def get_fechas_ocupadas(self, habitacion_id):
        if not habitacion_id:
            return []
        reservas = self.search([('habitacion_id', '=', habitacion_id)])
        ocupadas = []
        for r in reservas:
            if r.fecha_check_in and r.fecha_check_out:
                ocupadas.append({
                    'check_in': r.fecha_check_in.strftime('%Y-%m-%d'),
                    'check_out': r.fecha_check_out.strftime('%Y-%m-%d'),
                })
        return ocupadas

    # ============================================================
    # Creación de limpiezas automáticas
    # ============================================================
    def _crear_limpieza_automatica(self, tipo, fecha_base):
        self.ensure_one()
        limpieza_model = self.env['hotel.limpieza']
        stage_nuevo = self.env['hotel.limpieza.stage'].search([('name', '=', 'Nuevo')], limit=1)
        primer_empleado = self.env['hr.employee'].search([], limit=1).id if 'hr.employee' in self.env else False

        if tipo == 'checkin':
            fecha_inicio = fecha_base - timedelta(hours=2)
            fecha_fin = fecha_base - timedelta(hours=1)
            observacion = 'Limpieza de Check-In'
        else:
            fecha_inicio = fecha_base
            fecha_fin = fecha_base + timedelta(hours=1)
            observacion = 'Limpieza de Check-Out'

        limpieza_model.create({
            'habitacion_id': self.habitacion_id.id,
            'encargado_id': primer_empleado,
            'fecha_inicio': fecha_inicio,
            'fecha_fin': fecha_fin,
            'observaciones': observacion,
            'stage_id': stage_nuevo.id if stage_nuevo else False,
        })

    def _crear_limpiezas_diarias(self):
        self.ensure_one()

        if not self.fecha_check_in or not self.fecha_check_out:
            return

        fecha_inicio = self.fecha_check_in.date()
        fecha_fin = self.fecha_check_out.date()
        dias_intermedios = (fecha_fin - fecha_inicio).days - 1

        if dias_intermedios <= 0:
            return

        limpieza_model = self.env['hotel.limpieza']
        stage_nuevo = self.env['hotel.limpieza.stage'].search([('name', '=', 'Nuevo')], limit=1)
        primer_empleado = self.env['hr.employee'].search([], limit=1).id if 'hr.employee' in self.env else False

        for i in range(1, dias_intermedios + 1):
            dia = fecha_inicio + timedelta(days=i)
            fecha_inicio_limpieza = datetime.combine(dia, time(14, 0))
            fecha_fin_limpieza = fecha_inicio_limpieza + timedelta(hours=1)

            limpieza_model.create({
                'habitacion_id': self.habitacion_id.id,
                'encargado_id': primer_empleado,
                'fecha_inicio': fecha_inicio_limpieza,
                'fecha_fin': fecha_fin_limpieza,
                'observaciones': 'Limpieza diaria',
                'stage_id': stage_nuevo.id if stage_nuevo else False,
            })

    # ============================================================
    # Smartbutton / acción: facturar
    # ============================================================
    def action_facturar(self):
        for record in self:
            if record.factura_id:
                return {
                    'type': 'ir.actions.act_window',
                    'res_model': 'account.move',
                    'view_mode': 'form',
                    'res_id': record.factura_id.id,
                    'target': 'current',
                }

            # Crear factura (ajusta account_id según tu contabilidad)
            invoice_vals = {
                'move_type': 'out_invoice',
                'partner_id': record.id_cliente.id,
                'reserva_id': record.id,
                'invoice_line_ids': [
                    (0, 0, {
                        'name': f"Reserva {record.numero_reserva} - {(record.fecha_check_out - record.fecha_check_in).days} noches",
                        'quantity': 1,
                        'price_unit': record.monto_total_reserva,
                        'account_id': 26,  # ajustar si es necesario
                    })
                ],
            }
            factura = self.env['account.move'].create(invoice_vals)
            record.factura_id = factura.id

            return {
                'type': 'ir.actions.act_window',
                'res_model': 'account.move',
                'view_mode': 'form',
                'res_id': factura.id,
                'target': 'current',
            }

    
    @api.onchange('stage_id')
    def _onchange_stage_id_warning(self):
        """Muestra advertencia si se intenta finalizar sin pago."""
        if not self.stage_id:
            return
    
        try:
            stage_finalizado = self.env.ref('gestion_hotelera.finalizada_checkout')
        except Exception:
            return  # Si aún no existe el stage, no hacer nada
    
        # Si el usuario selecciona "Finalizada (Check-Out)"
        if self.stage_id == stage_finalizado:
    
            # Sin factura → advierte
            if not self.factura_id:
                return {
                    'warning': {
                        'title': 'Pago Requerido',
                        'message': 'No puedes finalizar la reserva porque no tiene factura.'
                    }
                }
    
            # Factura no pagada → advierte
            if self.factura_id.status_in_payment not in ('paid', 'posted'):
                return {
                    'warning': {
                        'title': 'Factura Pendiente',
                        'message': 'No puedes finalizar la reserva hasta que la factura esté pagada.'
                    }
                }

    @api.constrains('stage_id')
    def _check_pago_antes_finalizar(self):
        """Bloqueo absoluto: no finaliza si no está pagada."""
        for rec in self:
            try:
                stage_finalizado = rec.env.ref('gestion_hotelera.finalizada_checkout')
            except Exception:
                continue
    
            if rec.stage_id == stage_finalizado:
    
                # Sin factura → prohibido
                if not rec.factura_id:
                    raise exceptions.ValidationError(
                        "No puedes finalizar la reserva porque no tiene factura."
                    )
    
                # Factura no pagada → prohibido
                if rec.factura_id.status_in_payment not in ('paid', 'posted'):
                    raise exceptions.ValidationError(
                        "No puedes finalizar la reserva porque la factura aún no está pagada."
                    )
import pytz
import logging
from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError
from datetime import datetime, timedelta
from pytz import timezone

_logger = logging.getLogger(__name__)

class HotelLimpieza(models.Model):
    _name = 'hotel.limpieza'
    _description = 'Gestión de Limpieza'
    _order = 'fecha_inicio desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    # -------------------------
    # Campos
    # -------------------------
    name = fields.Char(
        string='Código',
        readonly=True,
        copy=False,
        default='LMP00',
        help="Código único generado por secuencia (prefijo LMP...).",
        tracking=True
    )

    stage_id = fields.Many2one(
        'hotel.limpieza.stage',
        string='Estado',
        required=True,
        tracking=True,
        group_expand='expand_stages',
        default=lambda self: self.env.ref('gestion_hotelera.stage_limpieza_nuevo', raise_if_not_found=False)
    )

    habitacion_id = fields.Many2one(
        'hotel.habitacion',
        string='Habitación',
        required=True,
        tracking=True
    )

    encargado_id = fields.Many2one(
        'hr.employee',
        string='Responsable',
        required=True,
        tracking=True
    )

    fecha_inicio = fields.Datetime(string='Fecha de Inicio', tracking=True)
    fecha_fin = fields.Datetime(string='Fecha de Fin', tracking=True)

    observaciones = fields.Text(string='Notas', tracking=True)

    is_historial = fields.Boolean(string='Es Historial', compute='_compute_is_historial', store=True, tracking=True)
    progreso = fields.Float(string='Progreso (%)', compute='_compute_progreso', store=True, tracking=True)

    color_class = fields.Char(string='Color Kanban', compute='_compute_color_class', store=True)
    color_gantt = fields.Integer(string='Color Gantt', compute='_compute_colors', store=True)
    color_list_html = fields.Html(string='Color', compute='_compute_color_list_html', store=False)

    campo_habitacion_gantt = fields.Char(string="Habitación (Gantt)", compute="_compute_campo_habitacion_gantt", store=True, tracking=True)
    encargado_gantt = fields.Char(string="Encargado (Gantt)", compute="_compute_encargado_gantt", store=True, tracking=True)

    estado_interno = fields.Selection(related="stage_id.estado_interno", store=True, tracking=True)

    fecha_finalizado_lmp = fields.Datetime(
        string='Fecha de Finalización', 
        readonly=True, 
        tracking=True
    )

    # -------------------------
    # Helpers (funciones internas reutilizables)
    # -------------------------
    def _to_datetime_if_string(self, value):
        """
        Convierte value a datetime si es string, o lo devuelve si ya es datetime/None.
        No lanza excepción: en caso de fallo devuelve None.
        """
        if not value:
            return None
        try:
            if isinstance(value, str):
                return fields.Datetime.from_string(value)
            return value
        except Exception as e:
            _logger.debug("Could not convert to datetime: %s (%s)", value, e)
            return None

    # -------------------------
    # 1) Computed: marcar si es historial
    # -------------------------
    @api.depends('stage_id')
    def _compute_is_historial(self):
        """
        Marca is_historial si la etapa actual es la etapa 'Historial' (referenciada por XML).
        """
        try:
            stage_historial = self.env.ref('gestion_hotelera.stage_limpieza_historial', raise_if_not_found=False)
        except Exception:
            stage_historial = None
        for rec in self:
            rec.is_historial = bool(stage_historial and rec.stage_id and rec.stage_id.id == stage_historial.id)

    # -------------------------
    # 2) Expandir stages en kanban (helper para widget)
    # -------------------------
    @api.model
    def expand_stages(self, stages, domain):
        """
        Devuelve todas las etapas para que el kanban muestre siempre todas las columnas.
        """
        stage_ids = stages.sudo()._search([], order=stages._order)
        return stages.browse(stage_ids)

    # -------------------------
    # 3) Progreso según estado
    # -------------------------
    @api.depends('stage_id')
    def _compute_progreso(self):
        """
        Asigna porcentaje de progreso según el estado interno de la etapa.
        """
        for rec in self:
            estado = rec.stage_id.estado_interno if rec.stage_id else False
            if estado == 'nuevo':
                rec.progreso = 0
            elif estado == 'en_progreso':
                rec.progreso = 50
            elif estado == 'finalizado':
                rec.progreso = 100
            else:
                rec.progreso = 0

    # -------------------------
    # 4) Color/orden Gantt
    # -------------------------
    @api.depends('fecha_inicio', 'stage_id.estado_interno')
    def _compute_colors(self):
        from pytz import timezone
        tz_mx = timezone("America/Mexico_City")
        for rec in self:
            gantt = 5  # valor por defecto
            estado = rec.stage_id.estado_interno if rec.stage_id else False
            # PRIORIDAD POR ESTADO
            if estado == 'en_progreso':
                gantt = 4
            elif estado == 'finalizado':
                gantt = 10
            elif estado == 'historial':
                gantt = 0
            else:
                # Lógica de fechas (solo para estado nuevo)
                if rec.fecha_inicio:
                    inicio_local = rec.fecha_inicio.astimezone(tz_mx)
                    ahora_local = fields.Datetime.now().astimezone(tz_mx)
                    diff_minutes = (inicio_local - ahora_local).total_seconds() / 60
    
                    if inicio_local.date() == ahora_local.date():
                        if 0 <= diff_minutes <= 59:
                            gantt = 1
                        elif 60 <= diff_minutes <= 119:
                            gantt = 2
                        elif diff_minutes > 120:
                            gantt = 3
                        else:
                            gantt = 1
                    else:
                        gantt = 5
    
            rec.color_gantt = gantt
    # -------------------------
    # 5) Color para kanban (clase CSS)
    # -------------------------
    @api.depends('fecha_inicio', 'stage_id.estado_interno')
    def _compute_color_class(self):
    
        for rec in self:
            if not rec.fecha_inicio:
                rec.color_class = '4_odooo'
                continue
    
            estado = rec.stage_id.estado_interno if rec.stage_id else False
            # PRIORIDAD POR ESTADO
            if estado == 'en_progreso':
                rec.color_class = '5_azul'
                continue
            elif estado == 'finalizado':
                rec.color_class = '6_verde'
                continue
            elif estado == 'historial':
                rec.color_class = '7_gris'
                continue
            # Lógica por fecha
            tz_mx = timezone("America/Mexico_City")
            inicio_local = rec.fecha_inicio.astimezone(tz_mx)
            ahora_local = fields.Datetime.now().astimezone(tz_mx)
            diferencia = (inicio_local - ahora_local).total_seconds() / 60
    
            if inicio_local.date() == ahora_local.date():
                if 0 <= diferencia <= 59:
                    rec.color_class = '1_rojo'
                elif 60 <= diferencia <= 119:
                    rec.color_class = '2_naranja'
                elif diferencia > 120:
                    rec.color_class = '3_amarillo'
                else:
                    rec.color_class = '1_rojo'
            else:
                rec.color_class = '4_odooo'
    # -------------------------
    # 6) Color list HTML (placeholder para compatibilidad)
    # -------------------------
    @api.depends('color_class')
    def _compute_color_list_html(self):
        """
        Computa una representación HTML mínima si se necesita render en listas.
        (Se mantiene simple; ajusta según tu CSS).
        """
        for rec in self:
            rec.color_list_html = '<span class="badge %s">%s</span>' % (rec.color_class or '4_odooo', rec.color_class or '')

    # -------------------------
    # 7) create() unificado (CORRECCIÓN DE SECUENCIA)
    # -------------------------
    @api.model_create_multi
    def create(self, vals_list):
        """
        create() modificado para:
        - Usar un placeholder ('TEMP_SEQ') en lugar de generar la secuencia real antes de super().create().
        - Esto previene que los IDs se salten si una restricción (como el solapamiento) falla.
        - Calcula fecha_fin = fecha_inicio + 1 hora si no se envía.
        - Valida que fecha_inicio <= fecha_fin.
        """
        seq_obj = self.env['ir.sequence']
        processed_vals = []

        for vals in vals_list:
            # --- 1) Secuencia: Usar un PLACEHOLDER temporal ('TEMP_SEQ')
            if not vals.get('name') or vals.get('name') in ('LMP00', 'New', 'Nuevo'):
                vals['name'] = 'TEMP_SEQ'

            # --- 2) Fecha: convertir si viene como string y calcular fecha_fin si falta ---
            fecha_inicio_val = vals.get('fecha_inicio')
            fecha_fin_val = vals.get('fecha_fin')

            fecha_inicio_dt = self._to_datetime_if_string(fecha_inicio_val)

            # Si se pudo convertir/obtener fecha_inicio, y no existe fecha_fin, calcularla
            if fecha_inicio_dt and not fecha_fin_val:
                fecha_fin_dt = fecha_inicio_dt + timedelta(hours=1)
                vals['fecha_fin'] = fields.Datetime.to_string(fecha_fin_dt)
                fecha_fin_val = vals['fecha_fin']  # actualizar referencia local

            # Si fecha_fin fue enviada como string -> convertir para validación
            fecha_fin_dt = self._to_datetime_if_string(fecha_fin_val)

            # --- 3) Validación mínima: fecha_inicio <= fecha_fin si ambos existen ---
            if fecha_inicio_dt and fecha_fin_dt:
                if fecha_inicio_dt > fecha_fin_dt:
                    raise ValidationError("La Fecha de Inicio no puede ser mayor que la Fecha de Fin.")

            processed_vals.append(vals)

        # 4. Llamada real a super. Esto es donde se disparan las constrains.
        # Si falla, se hace rollback y el ID no se consumió.
        new_records = super().create(processed_vals)

        # 5. Asignar la secuencia real SÓLO a los registros que se crearon exitosamente
        for record in new_records:
            if record.name == 'TEMP_SEQ':
                try:
                    # Generar la secuencia AHORA, después de que la validación haya pasado
                    record.name = seq_obj.next_by_code('hotel.limpieza.seq') or 'Nuevo'
                except Exception as e:
                    _logger.exception("Error generando secuencia para hotel.limpieza: %s", e)
                    # Si falla la secuencia por algún motivo, dejamos 'TEMP_SEQ'

        return new_records

    # -------------------------
    # 8) Onchange fecha_inicio (UI) — recalcula fecha_fin si corresponde
    # -------------------------
    @api.onchange('fecha_inicio')
    def _onchange_fecha_inicio(self):
        """
        Onchange ejecutado en formulario:
        - Si es un registro nuevo o fecha_fin no fue modificada manualmente, asigna fecha_fin = fecha_inicio + 1h.
        - Maneja fecha_inicio como str/datetime.
        """
        if not self.fecha_inicio:
            return

        # Obtener fecha_inicio del origen (registro anterior) con seguridad
        origen_inicio = getattr(self._origin, 'fecha_inicio', None)
        origen_inicio_dt = self._to_datetime_if_string(origen_inicio)

        # calcular la fecha_fin previa si existía
        fecha_fin_calculada_origen = (origen_inicio_dt + timedelta(hours=1)) if origen_inicio_dt else None

        # convertir self.fecha_inicio a datetime si es str
        inicio_dt = self._to_datetime_if_string(self.fecha_inicio)
        if not inicio_dt:
            # no podemos calcular si fecha_inicio inválida
            return

        # Si es nuevo (no tiene fecha_fin origen) o si fecha_fin actual coincide con la calculada anterior:
        origen_fecha_fin = getattr(self._origin, 'fecha_fin', None)
        origen_fecha_fin_dt = self._to_datetime_if_string(origen_fecha_fin)

        if (not origen_fecha_fin_dt) or (origen_fecha_fin_dt == fecha_fin_calculada_origen) or (not self.fecha_fin):
            # asignar fecha_fin a fecha_inicio + 1hora
            self.fecha_fin = inicio_dt + timedelta(hours=1)

    # -------------------------
    # 9) Campos para Gantt (texto)
    # -------------------------
    @api.depends('habitacion_id')
    def _compute_campo_habitacion_gantt(self):
        for rec in self:
            rec.campo_habitacion_gantt = f"Habitación: {rec.habitacion_id.name}" if rec.habitacion_id else "Habitación: N/A"

    @api.depends('encargado_id')
    def _compute_encargado_gantt(self):
        for rec in self:
            rec.encargado_gantt = f"Responsable: {rec.encargado_id.name}" if rec.encargado_id else "Responsable: N/A"

    # -------------------------
    # 10) Write: validaciones y acciones post-write (se mantiene tu lógica)
    # -------------------------
    def write(self, vals):
        """
        Mantiene las validaciones de cambio de etapa (no salir de historial, no retroceder etapas, sólo archivar desde finalizada).
        Después del write actualiza estados de la habitación según el tipo de limpieza determinado por observaciones.
        """
        stage_obj = self.env['hotel.limpieza.stage']
        stage_historial = self.env.ref('gestion_hotelera.stage_limpieza_historial', raise_if_not_found=False)
        stage_finalizada = self.env.ref('gestion_hotelera.stage_limpieza_finalizada', raise_if_not_found=False)

        # VALIDACIONES ANTES DEL WRITE
        for rec in self:
            if 'stage_id' in vals:
                new_stage = stage_obj.browse(vals['stage_id'])

                # *** LÓGICA DE REGISTRO DE FECHA DE FINALIZACIÓN (NUEVA) ***
                if stage_finalizada and new_stage.id == stage_finalizada.id:
                    vals['fecha_finalizado_lmp'] = fields.Datetime.now()

                # No dejar salir del historial
                if stage_historial and rec.stage_id.id == stage_historial.id and new_stage.id != stage_historial.id:
                    raise UserError("❌ No se puede mover un registro fuera del historial.")

                # Solo permitir mover a historial si está finalizada
                if stage_historial and new_stage.id == stage_historial.id:
                    if not stage_finalizada or rec.stage_id.id != stage_finalizada.id:
                        raise UserError("⚠️ Solo las limpiezas finalizadas pueden archivarse en el historial.")

                # No permitir regresar etapas
                if new_stage and rec.stage_id and new_stage.sequence < rec.stage_id.sequence:
                    raise UserError("❌ No se puede retroceder una limpieza a una etapa anterior.")

        # Ejecutar write real
        res = super().write(vals)

        # ETAPAS DE HABITACIÓN (referencias)
        stage_hab_disponible = self.env.ref('gestion_hotelera.stage_disponible', raise_if_not_found=False)
        stage_hab_ocupada = self.env.ref('gestion_hotelera.stage_ocupada', raise_if_not_found=False)
        stage_hab_limpieza = self.env.ref('gestion_hotelera.stage_limpieza', raise_if_not_found=False)

        # ETAPAS DE LIMPIEZA (referencias)
        stage_en_progreso = self.env.ref('gestion_hotelera.stage_limpieza_en_progreso', raise_if_not_found=False)
        stage_finalizada = self.env.ref('gestion_hotelera.stage_limpieza_finalizada', raise_if_not_found=False)

        # Ajustes post-write por registro
        for rec in self:
            obs = (rec.observaciones or "").lower().strip()
            tipo_checkin = "check-in" in obs or "check in" in obs
            tipo_diaria = "diaria" in obs
            tipo_checkout = "check-out" in obs or "check out" in obs

            # EN PROGRESO -> poner habitación en "limpieza" si aplica
            if stage_en_progreso and rec.stage_id.id == stage_en_progreso.id:
                if stage_hab_limpieza:
                    rec.habitacion_id.stage_id = stage_hab_limpieza
                continue

            # FINALIZADA -> ajustar etapa de habitación según tipo
            if stage_finalizada and rec.stage_id.id == stage_finalizada.id:
                if tipo_checkin and stage_hab_ocupada:
                    rec.habitacion_id.stage_id = stage_hab_ocupada
                elif tipo_diaria and stage_hab_ocupada:
                    rec.habitacion_id.stage_id = stage_hab_ocupada
                elif tipo_checkout and stage_hab_disponible:
                    rec.habitacion_id.stage_id = stage_hab_disponible
                elif stage_hab_disponible:
                    rec.habitacion_id.stage_id = stage_hab_disponible

        return res

    # -------------------------
    # 11) Acción para eliminar historial (botón)
    # -------------------------
    def eliminar_historial_lmp(self):
        """
        Borra todas las limpiezas cuya etapa sea 'Historial'.
        """
        stage_historial = self.env.ref('gestion_hotelera.stage_limpieza_historial', raise_if_not_found=False)
        if not stage_historial:
            raise UserError("❌ No se encontró la etapa Historial.")

        historial = self.search([('stage_id', '=', stage_historial.id)])
        if not historial:
            raise UserError("❌ No hay registros de historial para eliminar.")

        historial.unlink()
        return {'type': 'ir.actions.client', 'tag': 'reload'}


    # -----------------------------------------
    # 12) CRON JOB: MOVER A HISTORIAL AUTOMÁTICAMENTE (NUEVO)
    # -----------------------------------------
    @api.model
    def _automatizar_historial_lmp(self):
        """
        Mueve registros 'Finalizados' a 'Historial' si han pasado más de 1 minuto.
        """
        _logger.info("Ejecutando acción programada: _automatizar_historial de limpieza")
        
        # Uso correcto de las referencias de etapa de LIMPIEZA
        stage_finalizada = self.env.ref('gestion_hotelera.stage_limpieza_finalizada', raise_if_not_found=False)
        stage_historial = self.env.ref('gestion_hotelera.stage_limpieza_historial', raise_if_not_found=False)

        if not stage_finalizada or not stage_historial:
            _logger.warning("Faltan etapas Finalizada o Historial de LIMPIEZA. No se puede ejecutar el Cron Job.")
            return

        # Definir el tiempo límite: 1 minuto
        limite_tiempo = fields.Datetime.now() - timedelta(minutes=1)

        # Buscar registros de limpieza que cumplan la condición
        limpiezas_a_mover = self.search([
            ('stage_id', '=', stage_finalizada.id),
            ('fecha_finalizado_lmp', '<=', limite_tiempo)
        ])

        if limpiezas_a_mover:
            # Mover los registros al historial
            limpiezas_a_mover.write({'stage_id': stage_historial.id})
            _logger.info(f"Se movieron {len(limpiezas_a_mover)} registros de limpieza a Historial.")
        else:
            _logger.info("No se encontraron registros de limpieza para mover a Historial.")

    # ---------------------------
    # 13) Ordenar SOLO HISTORIAL por name asc
    # ---------------------------
    @api.model
    def _read_group_stage_id(self, stages, domain, order):
        """
        Ordena ÚNICAMENTE la columna Historial usando name asc.
        Las demás columnas usan su orden normal.
        """
        res = super()._read_group_stage_id(stages, domain, order)

        try:
            stage_historial = self.env.ref("gestion_hotelera.stage_limpieza_historial")
        except:
            return res

        for column in res:
            if column.get("stage_id") and column["stage_id"][0] == stage_historial.id:
                column["__domain"] = [("stage_id", "=", stage_historial.id)]
                column["__order"] = "name asc"

        return res
        
    # -----------------------------------------
    # 14) LÓGICA DE VALIDACIÓN (MENSAJE DE ERROR AJUSTADO)
    # -----------------------------------------
    @api.constrains('habitacion_id', 'fecha_inicio', 'fecha_fin', 'stage_id')
    def _check_overlap_limpieza(self):
        """
        Verifica que no haya superposición de fechas con otras órdenes de limpieza
        para la misma habitación que estén en estado 'Nuevo' o 'En Progreso'.
        """
        # Obtener los IDs de las etapas a considerar (nuevo y en_progreso)
        stage_nuevo = self.env.ref('gestion_hotelera.stage_limpieza_nuevo', raise_if_not_found=False)
        stage_progreso = self.env.ref('gestion_hotelera.stage_limpieza_en_progreso', raise_if_not_found=False)
        
        allowed_stage_ids = []
        if stage_nuevo:
            allowed_stage_ids.append(stage_nuevo.id)
        if stage_progreso:
            allowed_stage_ids.append(stage_progreso.id)

        if not allowed_stage_ids:
            return

        # 1. Chequeo de solapamiento con registros ya guardados en la BD
        for record in self:
            # Solo validar si el registro está en una etapa activa o va a una etapa activa
            if not record.stage_id or record.stage_id.id not in allowed_stage_ids:
                continue
                
            if not record.fecha_inicio or not record.fecha_fin or not record.habitacion_id:
                continue
                
            # Filtro base: misma habitación y estados 'nuevo' o 'en_progreso'
            domain = [
                ('habitacion_id', '=', record.habitacion_id.id),
                ('stage_id', 'in', allowed_stage_ids),
            ]
            
            # Excluir el registro actual SOLAMENTE si ya está en la base de datos
            if record.id:
                domain.append(('id', '!=', record.id))

            # Filtro de superposición de fechas: A.inicio < B.fin Y A.fin > B.inicio
            overlap_domain = domain + [
                ('fecha_inicio', '<', record.fecha_fin),
                ('fecha_fin', '>', record.fecha_inicio),
            ]

            overlapping_orders = self.search(overlap_domain, limit=1)

            if overlapping_orders:
                # ----------------------------------------------------
                # MENSAJE DE ERROR CON SALTOS DE LÍNEA PARA FORMATO DESEADO
                # ----------------------------------------------------
                # Formatear las fechas como string antes de pasarlas al mensaje
                exist_start_str = fields.Datetime.to_string(overlapping_orders.fecha_inicio)
                exist_end_str = fields.Datetime.to_string(overlapping_orders.fecha_fin)
                new_start_str = fields.Datetime.to_string(record.fecha_inicio)
                new_end_str = fields.Datetime.to_string(record.fecha_fin)
                
                msg = (
                    "¡Error de Superposición en Limpieza! \n\n"
                    "La habitación %(room_name)s ya tiene una orden activa \n"
                    "(%(order_name)s) programada entre:\n\n"
                    "%(exist_start)s y\n"
                    "%(exist_end)s \n\n"
                    "que se solapa con tu periodo:\n\n"
                    "%(new_start)s a\n"
                    "%(new_end)s \n\n"
                    "Por favor, ajusta las fechas."
                )
                
                raise ValidationError(msg % {
                    'room_name': record.habitacion_id.name,
                    'order_name': overlapping_orders.name,
                    'exist_start': exist_start_str,
                    'exist_end': exist_end_str,
                    'new_start': new_start_str,
                    'new_end': new_end_str,
                })

        # 2. Chequeo de solapamiento entre los registros que se están creando/modificando ahora
        records_to_check = [
            (i, rec) for i, rec in enumerate(self) 
            if rec.stage_id.id in allowed_stage_ids and rec.habitacion_id and rec.fecha_inicio and rec.fecha_fin
        ]

        for i, rec_a in records_to_check:
            for j, rec_b in records_to_check:
                if i >= j:
                    continue
                
                if rec_a.habitacion_id.id != rec_b.habitacion_id.id:
                    continue
                    
                if rec_a.fecha_inicio < rec_b.fecha_fin and rec_a.fecha_fin > rec_b.fecha_inicio:
                    # Solapamiento encontrado entre dos registros en la misma transacción
                    name_a = rec_a.name or 'Nueva'
                    name_b = rec_b.name or 'Nueva'

                    # ----------------------------------------------------
                    # Mensaje de Solapamiento de Transacción
                    # ----------------------------------------------------
                    msg_transaction = (
                        "¡Error de Solapamiento de Transacción! \n"
                        "Las órdenes de limpieza %(name_a)s y %(name_b)s para la habitación %(room_name)s se solapan "
                        "en la misma operación de guardado. \n"
                        "Por favor, corrige las fechas antes de continuar."
                    )
                    
                    raise ValidationError(msg_transaction % {
                        'name_a': name_a,
                        'name_b': name_b,
                        'room_name': rec_a.habitacion_id.name,
                    })

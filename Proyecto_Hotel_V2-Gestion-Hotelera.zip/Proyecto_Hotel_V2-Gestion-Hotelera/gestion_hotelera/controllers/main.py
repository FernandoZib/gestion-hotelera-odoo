from odoo import http
from odoo.http import request
from datetime import datetime, timedelta, time
import pytz
import random
import string
import logging

_logger = logging.getLogger(__name__)
class HotelYaxcheController(http.Controller):

    @http.route('/yaxche', type='http', auth='public', website=True)
    def hotel_yaxche_landing(self, **kwargs):
        # Renderizamos la plantilla que definiremos en el paso 5
        return request.render('gestion_hotelera.landing_page_template')
        
class HotelBookingWeb(http.Controller):

    # ================================================================
    # 1) Página principal (GET)
    # ================================================================
    @http.route('/habitaciones/reservar', type='http', auth='public', website=True, methods=['GET'])
    def hotel_rooms_multistep_booking(self, success_message=None, error_validation=None, **kw):
        return request.render(
            "gestion_hotelera.rooms_multistep_booking",
            {
                'page_title': "Reserva de Habitaciones",
                'success_message': success_message,
                'error_validation': error_validation,
            }
        )

    # ================================================================
    # 2) Obtener tipos de habitación disponibles (AJAX desde JS)
    # ================================================================
    @http.route('/habitaciones/tipos_disponibles', type='http', auth='public', website=True, csrf=False)
    def get_available_room_types(self, **kw):
        try:
            _logger.info("--- /habitaciones/tipos_disponibles REQUEST ---")
            _logger.info(f"params: {request.params}")

            check_in = request.params.get("check_in")
            check_out = request.params.get("check_out")

            if not check_in or not check_out:
                return request.make_json_response({"success": False, "error": "Faltan fechas."})

            try:
                check_in_dt = datetime.fromisoformat(check_in)
                check_out_dt = datetime.fromisoformat(check_out)
            except Exception:
                return request.make_json_response({"success": False, "error": "Formato de fecha inválido."})

            TipoHabitacion = request.env['hotel.habitacion.tipo'].sudo()
            Habitacion = request.env['hotel.habitacion'].sudo()
            Reserva = request.env['hotel.reserva'].sudo()

            available_types = []

            for t in TipoHabitacion.search([]):
                habitaciones = Habitacion.search([('tipo_habitacion_id', '=', t.id)])
                encontrado = False
                for hab in habitaciones:
                    overlapping = Reserva.search_count([
                        ('habitacion_id', '=', hab.id),
                        ('fecha_check_in', '<', check_out_dt),
                        ('fecha_check_out', '>', check_in_dt),
                    ])
                    if overlapping == 0:
                        encontrado = True
                        break
                if encontrado:
                    t.imagen_ids  # Forzar carga de relación
                    available_types.append(t)

            html = request.env['ir.ui.view']._render_template(
                'gestion_hotelera.rooms_type_selection_content',
                {
                    'room_types': available_types,
                    'check_in': check_in,
                    'check_out': check_out,
                }
            )

            return request.make_json_response({"success": True, "html": html})

        except Exception as e:
            _logger.exception("Error en tipos_disponibles")
            return request.make_json_response({"success": False, "error": f"SERVER ERROR: {e}"}, status=500)

    # ================================================================
    # 3) Obtener habitaciones específicas disponibles (AJAX desde JS)
    # ================================================================
    @http.route('/habitaciones/especificas_disponibles', type='http', auth='public', website=True, csrf=False)
    def get_available_specific_rooms(self, **kw):
        try:
            _logger.info("--- /habitaciones/especificas_disponibles REQUEST ---")
            _logger.info(f"params: {request.params}")

            tipo_id = request.params.get("tipo_id")
            check_in = request.params.get("check_in")
            check_out = request.params.get("check_out")

            if not tipo_id or not check_in or not check_out:
                return request.make_json_response({"success": False, "error": "Datos incompletos."})

            try:
                tipo_id = int(tipo_id)
                check_in_dt = datetime.fromisoformat(check_in)
                check_out_dt = datetime.fromisoformat(check_out)
            except Exception:
                return request.make_json_response({"success": False, "error": "Datos inválidos."})

            Habitacion = request.env['hotel.habitacion'].sudo()
            Reserva = request.env['hotel.reserva'].sudo()

            disponibles = []
            for hab in Habitacion.search([('tipo_habitacion_id', '=', tipo_id)]):
                overlapping = Reserva.search_count([
                    ('habitacion_id', '=', hab.id),
                    ('fecha_check_in', '<', check_out_dt),
                    ('fecha_check_out', '>', check_in_dt),
                ])
                if overlapping == 0:
                    disponibles.append(hab)

            html = request.env['ir.ui.view']._render_template(
                'gestion_hotelera.rooms_specific_selection_content',
                {'rooms': disponibles}
            )

            return request.make_json_response({"success": True, "html": html})

        except Exception as e:
            _logger.exception("Error en especificas_disponibles")
            return request.make_json_response({"success": False, "error": f"SERVER ERROR: {e}"}, status=500)

    # ================================================================
    # 4) CALCULAR PRECIO (NUEVO)
    # ================================================================
    @http.route('/habitaciones/calcular_precio', type='json', auth='public', methods=['POST'], csrf=False)
    def calculate_booking_price(self, habitacion_id, check_in, check_out):
        """
        Calcula el precio total de una reserva basándose en:
        - Precio por noche de la habitación
        - Tarifas especiales aplicables en el rango de fechas
        """
        try:
            _logger.info(f"💰 Calculando precio para habitación {habitacion_id}")
            
            # Convertir strings a datetime
            fecha_in = datetime.strptime(check_in, '%Y-%m-%d %H:%M')
            fecha_out = datetime.strptime(check_out, '%Y-%m-%d %H:%M')
            
            # Validación básica
            if fecha_in >= fecha_out:
                return {
                    'success': False,
                    'error': 'La fecha de check-in debe ser anterior a la de check-out'
                }
            
            # Buscar habitación
            habitacion = request.env['hotel.habitacion'].sudo().browse(int(habitacion_id))
            if not habitacion.exists():
                return {
                    'success': False,
                    'error': 'Habitación no encontrada'
                }
            
            # Buscar precio de la habitación
            precio_model = request.env['hotel.precio'].sudo()
            precio_reg = precio_model.search([
                ('id_habitacion', '=', habitacion.id)
            ], limit=1)
            
            if not precio_reg:
                return {
                    'success': False,
                    'error': 'Esta habitación no tiene precio asignado'
                }
            
            precio_noche = precio_reg.precio_noche
            
            # Calcular número de noches
            fecha_ini = fecha_in.date()
            fecha_fin = fecha_out.date()
            num_noches = (fecha_fin - fecha_ini).days
            
            if num_noches <= 0:
                return {
                    'success': False,
                    'error': 'La reserva debe ser de al menos 1 noche'
                }
            
            # Calcular subtotal base
            subtotal = precio_noche * num_noches
            
            # Buscar tarifas aplicables
            tarifa_model = request.env['hotel.tarifa'].sudo()
            
            # Buscar precios de esta habitación que tengan tarifa
            precios_con_tarifa = precio_model.search([
                ('id_habitacion', '=', habitacion.id),
                ('id_tarifa', '!=', False)
            ])
            
            tarifas_ids = precios_con_tarifa.mapped('id_tarifa').ids
            
            # Buscar tarifas que se solapen con el rango de fechas
            tarifas_aplicables = tarifa_model.search([
                ('id', 'in', tarifas_ids),
                ('fecha_inicio', '<=', fecha_fin),
                ('fecha_fin', '>=', fecha_ini)
            ])
            
            # Construir lista de tarifas aplicadas
            tarifas_info = []
            tarifas_usadas = set()
            total_tarifas = 0.0
            
            # Determinar qué tarifas aplican por cada noche
            for i in range(num_noches):
                dia_actual = fecha_ini + timedelta(days=i)
                
                tarifa_dia = tarifas_aplicables.filtered(
                    lambda t: t.fecha_inicio <= dia_actual <= t.fecha_fin
                )
                
                if tarifa_dia:
                    tarifas_usadas.add(tarifa_dia[0].id)
            
            # Sumar cada tarifa única una sola vez
            for tarifa_id in tarifas_usadas:
                tarifa = tarifa_model.browse(tarifa_id)
                total_tarifas += tarifa.precio_temporada
                
                tarifas_info.append({
                    'nombre': tarifa.name,
                    'precio': tarifa.precio_temporada,
                    'fechas': f"{tarifa.fecha_inicio.strftime('%d/%m/%Y')} - {tarifa.fecha_fin.strftime('%d/%m/%Y')}"
                })
            
            total_final = subtotal + total_tarifas
            
            # Generar desglose en HTML
            desglose_html = f"""
                <div class="price-breakdown">
                    <div class="breakdown-row">
                        <span>Precio por noche:</span>
                        <span class="price">${precio_noche:,.2f}</span>
                    </div>
                    <div class="breakdown-row">
                        <span>Número de noches:</span>
                        <span>{num_noches}</span>
                    </div>
                    <div class="breakdown-row subtotal">
                        <span><strong>Subtotal:</strong></span>
                        <span class="price"><strong>${subtotal:,.2f}</strong></span>
                    </div>
            """
            
            if tarifas_info:
                desglose_html += '<div class="breakdown-separator"></div>'
                desglose_html += '<div class="breakdown-section-title">Tarifas especiales:</div>'
                
                for tarifa in tarifas_info:
                    desglose_html += f"""
                        <div class="breakdown-row tarifa">
                            <div>
                                <div class="tarifa-nombre">{tarifa['nombre']}</div>
                                <div class="tarifa-fechas">{tarifa['fechas']}</div>
                            </div>
                            <span class="price">+${tarifa['precio']:,.2f}</span>
                        </div>
                    """
            
            desglose_html += f"""
                    <div class="breakdown-separator"></div>
                    <div class="breakdown-row total">
                        <span><strong>TOTAL:</strong></span>
                        <span class="price-total">${total_final:,.2f}</span>
                    </div>
                </div>
            """
            
            _logger.info(f"✅ Precio calculado: ${total_final:,.2f} ({num_noches} noches)")
            
            return {
                'success': True,
                'precio_noche': precio_noche,
                'num_noches': num_noches,
                'subtotal': subtotal,
                'tarifas_aplicadas': tarifas_info,
                'total_tarifas': total_tarifas,
                'total': total_final,
                'desglose': desglose_html
            }
            
        except Exception as e:
            _logger.exception("Error al calcular precio")
            return {
                'success': False,
                'error': f'Error al calcular precio: {str(e)}'
            }

    # ================================================================
    # 5) ENVIAR CÓDIGO DE VERIFICACIÓN (NUEVO)
    # ================================================================
    @http.route('/habitaciones/enviar_codigo_verificacion', type='json', auth='public', methods=['POST'], csrf=False)
    def send_verification_code(self, email):
        """Genera y envía un código de verificación por email"""
        
        try:
            # Validar formato básico del email
            if not email or '@' not in email:
                return {'success': False, 'error': 'Email inválido'}
            
            # Generar código de 6 dígitos
            code = ''.join(random.choices(string.digits, k=6))
            
            _logger.info(f"🔔 Generando código {code} para {email}")
            
            # Guardar código en sesión con timestamp
            request.session['verification_code'] = code
            request.session['verification_email'] = email
            request.session['verification_timestamp'] = datetime.now().isoformat()
            
            # Crear el cuerpo del email con HTML
            email_body = f"""
                <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa; padding: 20px;">
                    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
                        <h1 style="color: white; margin: 0; font-size: 28px;">🏨 Verificación de Email</h1>
                    </div>
                    
                    <div style="background: white; padding: 40px; border-radius: 0 0 10px 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                        <p style="font-size: 16px; color: #333; margin-bottom: 20px;">¡Hola! 👋</p>
                        
                        <p style="font-size: 16px; color: #555; line-height: 1.6;">
                            Estás a punto de completar tu reserva. Para confirmar tu correo electrónico, utiliza el siguiente código:
                        </p>
                        
                        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                                    padding: 20px; 
                                    margin: 30px 0; 
                                    border-radius: 10px; 
                                    text-align: center;">
                            <h1 style="color: white; 
                                       letter-spacing: 8px; 
                                       font-size: 42px; 
                                       margin: 0; 
                                       font-weight: bold;">
                                {code}
                            </h1>
                        </div>
                        
                        <div style="background: #fff3cd; 
                                    border-left: 4px solid #ffc107; 
                                    padding: 15px; 
                                    margin: 20px 0; 
                                    border-radius: 5px;">
                            <p style="margin: 0; color: #856404; font-size: 14px;">
                                ⏰ <strong>Este código expira en 5 minutos.</strong>
                            </p>
                        </div>
                        
                        <p style="font-size: 14px; color: #666; line-height: 1.6; margin-top: 20px;">
                            Si no solicitaste este código, puedes ignorar este mensaje de forma segura.
                        </p>
                        
                        <hr style="border: none; border-top: 1px solid #e0e0e0; margin: 30px 0;"/>
                        
                        <p style="color: #999; font-size: 12px; text-align: center; margin: 0;">
                            Sistema de Reservas Hotel<br/>
                            Este es un correo automático, por favor no responder.
                        </p>
                    </div>
                </div>
            """
            
            # Obtener mail server
            mail_server = request.env['ir.mail_server'].sudo().search([], limit=1)
            email_from = mail_server.smtp_user if mail_server else 'noreply@hotel.com'
            
            # Crear y enviar el email
            mail_values = {
                'subject': f'Tu código de verificación es: {code}',
                'body_html': email_body,
                'email_from': email_from,
                'email_to': email,
                'auto_delete': True,
            }
            
            mail = request.env['mail.mail'].sudo().create(mail_values)
            mail.send()
            
            _logger.info(f"✅ Email enviado exitosamente a {email}")
            
            return {
                'success': True,
                'message': f'✓ Código enviado a {email}'
            }
            
        except Exception as e:
            _logger.exception(f"❌ Error al enviar email a {email}")
            return {
                'success': False,
                'error': f'Error al enviar el email: {str(e)}'
            }
    
    # ================================================================
    # 6) VERIFICAR CÓDIGO (NUEVO)
    # ================================================================
    @http.route('/habitaciones/verificar_codigo', type='json', auth='public', methods=['POST'], csrf=False)
    def verify_code(self, email, code):
        """Verifica que el código sea correcto"""
        
        try:
            stored_code = request.session.get('verification_code')
            stored_email = request.session.get('verification_email')
            timestamp_str = request.session.get('verification_timestamp')
            
            _logger.info(f"🔍 Verificando código para {email}")
            
            if not all([stored_code, stored_email, timestamp_str]):
                return {'success': False, 'error': 'No hay código pendiente de verificación'}
            
            # Verificar que el email coincida
            if email != stored_email:
                return {'success': False, 'error': 'El email no coincide'}
            
            # Verificar que no haya expirado (5 minutos)
            timestamp = datetime.fromisoformat(timestamp_str)
            if datetime.now() - timestamp > timedelta(minutes=5):
                return {'success': False, 'error': 'El código ha expirado. Solicita uno nuevo'}
            
            # Verificar el código
            if code != stored_code:
                _logger.warning(f"❌ Código incorrecto para {email}: esperaba {stored_code}, recibió {code}")
                return {'success': False, 'error': 'Código incorrecto'}
            
            # Marcar como verificado
            request.session['email_verified'] = True
            request.session['verified_email'] = email
            
            # Limpiar datos de verificación
            request.session.pop('verification_code', None)
            request.session.pop('verification_timestamp', None)
            
            _logger.info(f"✅ Email verificado correctamente: {email}")
            
            return {
                'success': True,
                'message': 'Email verificado correctamente'
            }
            
        except Exception as e:
            _logger.exception(f"Error al verificar código para {email}")
            return {
                'success': False,
                'error': f'Error en la verificación: {str(e)}'
            }
    
    # ================================================================
    # 7) CREAR RESERVA (POST) - VERSIÓN FUSIONADA
    # ================================================================
    @http.route('/habitaciones/reservar', type='http', auth='public', methods=['POST'], csrf=True, website=True)
    def create_hotel_reservation(self, **post):
        try:
            _logger.info("--- /habitaciones/reservar (POST) ---")
            _logger.info(f"post: {post}")
            
            # ============================================
            # VERIFICAR EMAIL ANTES DE CONTINUAR
            # ============================================
            email_verified = request.session.get('email_verified', False)
            verified_email = request.session.get('verified_email', '')
            submitted_email = post.get('partner_email', '')
            
            if not email_verified or verified_email != submitted_email:
                _logger.warning(f"❌ Email no verificado: {submitted_email}")
                return request.render('gestion_hotelera.rooms_multistep_booking', {
                    'error_validation': 'Debes verificar tu email antes de completar la reserva',
                    'page_title': 'Reservar Habitación'
                })
    
            habitacion_id = int(post.get('habitacion_id') or 0)
            check_in_raw = post.get('fecha_check_in')
            check_out_raw = post.get('fecha_check_out')
            partner_name = post.get('partner_name')
            partner_email = post.get('partner_email')
    
            if not all([habitacion_id, check_in_raw, check_out_raw, partner_name, partner_email]):
                return request.render(
                    "gestion_hotelera.rooms_multistep_booking",
                    {
                        'error_validation': "Faltan datos para crear la reserva.",
                        'page_title': 'Reservar Habitación'
                    }
                )
    
            # Extraer solo la fecha
            def extract_date(value):
                if "T" in value:
                    return value.split("T")[0]
                if " " in value:
                    return value.split(" ")[0]
                return value
    
            fecha_in = extract_date(check_in_raw)
            fecha_out = extract_date(check_out_raw)
    
            # Forzar siempre 12:00 PM en zona horaria de México
            tz = pytz.timezone("America/Mexico_City")
            
            try:
                fecha_in_date = datetime.strptime(fecha_in, "%Y-%m-%d").date()
                fecha_out_date = datetime.strptime(fecha_out, "%Y-%m-%d").date()
            
                check_in_dt_local = tz.localize(datetime.combine(fecha_in_date, time(12, 0, 0)))
                check_out_dt_local = tz.localize(datetime.combine(fecha_out_date, time(12, 0, 0)))
            
                check_in_dt = check_in_dt_local.astimezone(pytz.utc)
                check_out_dt = check_out_dt_local.astimezone(pytz.utc)
            
            except Exception:
                return request.render(
                    "gestion_hotelera.rooms_multistep_booking",
                    {
                        'error_validation': "Formato de fechas inválido.",
                        'page_title': 'Reservar Habitación'
                    }
                )
            
            check_in = check_in_dt.strftime("%Y-%m-%d %H:%M:%S")
            check_out = check_out_dt.strftime("%Y-%m-%d %H:%M:%S")

            # Validar que check_out > check_in
            if check_out_dt <= check_in_dt:
                return request.render(
                    "gestion_hotelera.rooms_multistep_booking",
                    {
                        'error_validation': "La fecha de salida debe ser mayor que la fecha de entrada.",
                        'page_title': 'Reservar Habitación'
                    }
                )
    
            Partner = request.env['res.partner'].sudo()
            Reserva = request.env['hotel.reserva'].sudo()
            Habitacion = request.env['hotel.habitacion'].sudo()
    
            # Verificar solapamiento
            overlapping = Reserva.search_count([
                ('habitacion_id', '=', habitacion_id),
                ('fecha_check_in', '<', check_out_dt),
                ('fecha_check_out', '>', check_in_dt),
            ])
    
            if overlapping > 0:
                return request.render(
                    "gestion_hotelera.rooms_multistep_booking",
                    {
                        'error_validation': "La habitación ya está reservada en esas fechas.",
                        'page_title': 'Reservar Habitación'
                    }
                )
    
            # Partner
            partner = Partner.search([('email', '=', partner_email)], limit=1)
            if not partner:
                partner = Partner.create({
                    'name': partner_name,
                    'email': partner_email,
                    'phone': post.get('partner_phone', ''),
                })
    
            room = Habitacion.browse(habitacion_id)
            if not room.exists():
                return request.render(
                    "gestion_hotelera.rooms_multistep_booking",
                    {
                        'error_validation': "Habitación no válida.",
                        'page_title': 'Reservar Habitación'
                    }
                )
    
            # Crear Reserva
            notas_completas = f"Reserva hecha desde la web por {partner_name}"
            if post.get('booking_notes'):
                notas_completas += f"\n\nNotas del cliente: {post.get('booking_notes')}"
            
            reserva = Reserva.create({
                'id_cliente': partner.id,
                'habitacion_id': room.id,
                'tipo_habitacion_id': room.tipo_habitacion_id.id,
                'fecha_check_in': check_in,
                'fecha_check_out': check_out,
                'notas': notas_completas,
            })
            
            _logger.info(f"✅ Reserva creada exitosamente: {reserva.numero_reserva}")
            
            # Limpiar sesión
            request.session.pop('email_verified', None)
            request.session.pop('verified_email', None)
    
            success_msg = f"¡Reserva confirmada! Te esperamos con los brazos abiertos"
            return request.redirect(f'/habitaciones/reservar?success_message={success_msg}')
    
        except Exception as e:
            _logger.exception("Error al crear reserva")
            return request.render(
                "gestion_hotelera.rooms_multistep_booking",
                {
                    'error_validation': f"Error al procesar la reserva: {str(e)}",
                    'page_title': 'Reservar Habitación'
                }
            )
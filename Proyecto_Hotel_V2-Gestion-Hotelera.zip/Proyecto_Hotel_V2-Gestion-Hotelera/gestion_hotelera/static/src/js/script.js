document.addEventListener('DOMContentLoaded', function () {
    console.log("Hotel Yaxché: Iniciando script...");

    // 1. Inicializar iconos Lucide (si la librería cargó)
    if (window.lucide && typeof window.lucide.createIcons === 'function') {
        window.lucide.createIcons();
    }

    // 2. Referencias a elementos
    const navbar = document.getElementById('navbar');
    const mobileBtn = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');

    // 3. Menú Móvil (Solo si existen los botones)
    if (mobileBtn && mobileMenu) {
        mobileBtn.addEventListener('click', function () {
            const isHidden = mobileMenu.style.display === '' || mobileMenu.style.display === 'none';
            mobileMenu.style.display = isHidden ? 'block' : 'none';

            if (!isHidden) {
                // Cerrando menú
                if (window.scrollY === 0 && navbar) navbar.classList.remove('scrolled');
            } else {
                // Abriendo menú
                if (navbar) navbar.classList.add('scrolled');
            }
        });
    }

    // 4. Efecto Scroll en Navbar
    if (navbar) {
        window.addEventListener('scroll', function () {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                // Solo quitar fondo si el menú móvil está cerrado
                if (!mobileMenu || mobileMenu.style.display === '' || mobileMenu.style.display === 'none') {
                    navbar.classList.remove('scrolled');
                }
            }
        });
    }

    // 5. Fade In (Aparición suave) - CRUCIAL PARA QUE NO SE VEA BLANCO
    const fadeSections = document.querySelectorAll('.fade-in-section');
    
    if (fadeSections.length > 0) {
        // Opción A: Usar IntersectionObserver (Moderno)
        if ('IntersectionObserver' in window) {
            const obs = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, { root: null, threshold: 0.1 }); // Bajé el threshold a 0.1 para que aparezca más rápido

            fadeSections.forEach(s => obs.observe(s));
        } 
        // Opción B: Fallback (Si el navegador es viejo, mostrar todo de inmediato)
        else {
            fadeSections.forEach(s => s.classList.add('is-visible'));
        }
    } else {
        console.warn("No se encontraron secciones con clase .fade-in-section");
    }

    // 6. Smooth Scroll
    document.querySelectorAll('a[href^="#"]').forEach(a => {
        a.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (!href || href === '#') return;
            
            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                // Cerrar menú móvil si está abierto
                if (mobileMenu && mobileMenu.style.display === 'block') {
                    mobileMenu.style.display = 'none';
                }
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
});
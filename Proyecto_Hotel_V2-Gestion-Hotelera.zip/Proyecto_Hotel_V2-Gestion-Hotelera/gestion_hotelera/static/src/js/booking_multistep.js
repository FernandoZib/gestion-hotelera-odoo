/** @odoo-module **/

import publicWidget from "@web/legacy/js/public/public_widget";

function toggleLoading(selector, show) {
    const btn = $(selector);
    const target = btn.is('button') ? btn : btn.find('button');

    if (!target.length) return;

    if (show) {
        target.prop('disabled', true);
        target.addClass('disabled');
        target.find('.btn-text').addClass('d-none');
        target.find('.spinner-border').removeClass('d-none');
        target.find('.fa').addClass('d-none'); 
    } else {
        target.prop('disabled', false);
        target.removeClass('disabled');
        target.find('.btn-text').removeClass('d-none');
        target.find('.spinner-border').addClass('d-none');
        target.find('.fa').removeClass('d-none');
    }
}

publicWidget.registry.MultistepBooking = publicWidget.Widget.extend({
    selector: '#multistep_booking_form',

    events: {
        'submit #date_selection_form': '_onSearchDates',
        'click .btn-select-room': '_onSelectRoomType', 
        'click .specific-room-card button': '_onSelectSpecificRoom',
        'click #btn-back-types': '_onBackToTypes',
        'click #btn-back-dates': '_onBackToDates',
        'click #btn-back-rooms': '_onBackToRooms',
        'click .btn-ver-galeria': '_onOpenGallery',
        'click .carousel-main-img': '_onImageClick',
        
        // Eventos de verificación de email
        'click #btn-send-verification': '_onSendVerificationCode',
        'click #btn-verify-code': '_onCheckVerificationCode',
    },

    start: function () {
        this.isBusy = false;

        this.$step1 = this.$('#step-dates');
        this.$step2 = this.$('#step-types');
        this.$step3 = this.$('#step-rooms');
        this.$step4 = this.$('#step-user-data');
    
        this.$steps = [this.$step1, this.$step2, this.$step3, this.$step4];
        this.$alertContainer = this.$('#booking-alerts');
    
        const storedCheckIn = localStorage.getItem('check_in_date');
        const storedCheckOut = localStorage.getItem('check_out_date');
    
        const checkInInput = this.$('#fecha_check_in');
        const checkOutInput = this.$('#fecha_check_out');
    
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        const todayStr = `${yyyy}-${mm}-${dd}`;
    
        checkInInput.attr("min", todayStr);
        checkOutInput.attr("min", todayStr);
    
        if (storedCheckIn) {
            checkInInput.val(storedCheckIn);
        } else {
            checkInInput.val(todayStr);
        }
    
        let baseDate = storedCheckIn ? new Date(storedCheckIn) : today;
        const tomorrow = new Date(baseDate.getTime() + 86400000);
    
        const yyyy2 = tomorrow.getFullYear();
        const mm2 = String(tomorrow.getMonth() + 1).padStart(2, '0');
        const dd2 = String(tomorrow.getDate()).padStart(2, '0');
        const tomorrowStr = `${yyyy2}-${mm2}-${dd2}`;
    
        checkOutInput.attr("min", tomorrowStr);
    
        if (storedCheckOut) {
            checkOutInput.val(storedCheckOut);
        } else {
            checkOutInput.val(tomorrowStr);
        }
    
        checkInInput.on("change", () => {
            const inDate = new Date(checkInInput.val());
            if (isNaN(inDate)) return;
    
            const minCheckout = new Date(inDate.getTime() + 86400000);
    
            const y = minCheckout.getFullYear();
            const m = String(minCheckout.getMonth() + 1).padStart(2, '0');
            const d = String(minCheckout.getDate()).padStart(2, '0');
            const newMin = `${y}-${m}-${d}`;
    
            checkOutInput.attr("min", newMin);
    
            if (checkOutInput.val() < newMin) {
                checkOutInput.val(newMin);
            }
        });
    
        const formDates = this.$('#date_selection_form');
        formDates.on("submit", (ev) => {
            const cIn = new Date(checkInInput.val());
            const cOut = new Date(checkOutInput.val());
    
            if (!checkInInput.val() || !checkOutInput.val()) {
                ev.preventDefault();
                this._showError("Por favor selecciona ambas fechas.");
                return;
            }
    
            if (cOut <= cIn) {
                ev.preventDefault();
                this._showError("La fecha de salida debe ser mayor que la fecha de entrada.");
                return;
            }
        });

        // Bloquear botón de confirmación final hasta verificar email
        this.$finalSubmitBtn = this.$('#btn-final-submit');
        if (this.$finalSubmitBtn.length) {
            this.$finalSubmitBtn.prop('disabled', true);
            console.log('✅ Botón de confirmación bloqueado hasta verificar email');
        } else {
            console.warn('⚠️ No se encontró el botón #btn-final-submit');
        }
    
        this._updateStepVisibility(1);
        return this._super.apply(this, arguments);
    },

    _updateStepVisibility: function (activeStep) {
        // Pausa defensiva de carruseles antes de ocultar el contenedor
        if (this.$('.carousel').length) {
            try {
                this.$('.carousel').carousel('pause');
            } catch(e) { }
        }

        this.$steps.forEach(($step, index) => {
            const num = index + 1;
            if (num === activeStep) {
                $step.removeClass('d-none').addClass('d-block');
            } else {
                $step.removeClass('d-block').addClass('d-none');
            }
        });
        
        if (this.$el && this.$el.length) {
            this.$el[0].scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    },

    // =========================================================================
    //  VERIFICACIÓN DE EMAIL (PASO 4)
    // =========================================================================

    _onSendVerificationCode: function (ev) {
        ev.preventDefault();
        const btn = ev.currentTarget;
        const email = this.$('#partner_email').val();

        if (!email || !email.includes('@')) {
            this._showError('Por favor ingresa un email válido');
            return;
        }

        toggleLoading(btn, true);
        this.$alertContainer.empty();

        $.ajax({
            url: '/habitaciones/enviar_codigo_verificacion',
            type: 'POST',
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({
                jsonrpc: "2.0",
                method: "call",
                params: { email: email }
            }),
            success: (data) => {
                const result = data.result;
                if (result && result.success) {
                    this._showSuccess(result.message);
                    this.$('.verification-code-section').removeClass('d-none');
                    this.$('#partner_email').prop('readonly', true);
                    $(btn).addClass('d-none');
                } else {
                    this._showError(result && result.error ? result.error : 'Error al enviar código');
                }
            },
            error: () => {
                this._showError('Error de conexión con el servidor.');
            },
            complete: () => {
                toggleLoading(btn, false);
            }
        });
    },

    _onCheckVerificationCode: function (ev) {
        ev.preventDefault();
        const btn = ev.currentTarget;
        const email = this.$('#partner_email').val();
        const code = this.$('#verification_code').val();

        if (!code) {
            this._showError('Por favor ingresa el código');
            return;
        }

        toggleLoading(btn, true);

        $.ajax({
            url: '/habitaciones/verificar_codigo',
            type: 'POST',
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({
                jsonrpc: "2.0",
                method: "call",
                params: { email: email, code: code }
            }),
            success: (data) => {
                const result = data.result;
                if (result && result.success) {
                    this._showSuccess('¡Email verificado correctamente!');
                    this.$('.verification-code-section').addClass('d-none');
                    
                    // Desbloquear botón final de confirmación
                    if (this.$finalSubmitBtn.length) {
                        this.$finalSubmitBtn.prop('disabled', false);
                        this.$finalSubmitBtn.removeClass('btn-secondary').addClass('btn-primary');
                    }
                    
                    // Feedback visual
                    this.$('#partner_email').parent().append('<span class="badge bg-success ms-2">✓ Verificado</span>');
                } else {
                    this._showError(result && result.error ? result.error : 'Código incorrecto');
                }
            },
            error: () => {
                this._showError('Error al verificar código.');
            },
            complete: () => {
                toggleLoading(btn, false);
            }
        });
    },

    // =========================================================================
    //  BÚSQUEDA Y NAVEGACIÓN
    // =========================================================================

    _onSearchDates: function (ev) {
        ev.preventDefault();

        if (this.isBusy) return;
        this.isBusy = true;

        const checkIn = this.$('#fecha_check_in').val();
        const checkOut = this.$('#fecha_check_out').val();

        if (!checkIn || !checkOut) {
            this._showError("Por favor selecciona ambas fechas.");
            this.isBusy = false; 
            return;
        }

        localStorage.setItem('check_in_date', checkIn);
        localStorage.setItem('check_out_date', checkOut);

        toggleLoading('#btn-search-types', true);
        this.$alertContainer.empty();

        $.ajax({
            url: '/habitaciones/tipos_disponibles',
            type: 'POST',
            data: {
                check_in: checkIn,
                check_out: checkOut,
            },
            success: (data) => {
                if (!data || !data.success) {
                    this._showError(data && data.error ? data.error : "No se pudieron obtener los tipos de habitación.");
                    return;
                }

                this.$('#room_types_container').html(data.html);
                this._initCarousels();
                this._updateStepVisibility(2);
            },
            error: (xhr) => {
                let msg = "Error al consultar la disponibilidad.";
                try {
                    const j = JSON.parse(xhr.responseText);
                    if (j && j.error) msg = j.error;
                } catch (e) {}
                this._showError(msg);
            },
            complete: () => {
                toggleLoading('#btn-search-types', false);
                this.isBusy = false;
            }
        });
    },

    _initCarousels: function() {
        this.$('.carousel').each(function() {
            const $carousel = $(this);
            
            $carousel.on('slid.bs.carousel', function() {
                const activeIndex = $(this).find('.carousel-item.active').index();
                const $thumbnails = $(this).find('.thumb-indicator:not(.thumb-more)');
                
                $thumbnails.removeClass('active');
                $thumbnails.eq(activeIndex).addClass('active');
            });
            
            $carousel.on('mouseenter', function() {
                $(this).carousel('pause');
            });
            
            $carousel.on('mouseleave', function() {
                $(this).carousel('cycle');
            });
        });
    },

    _onOpenGallery: function(ev) {
        ev.preventDefault();
        ev.stopPropagation();
        
        const $target = $(ev.currentTarget);
        const roomTypeId = $target.data('room-type-id');
        const $carousel = $(`#carousel_${roomTypeId}`);
        
        if (!$carousel.length) return;
        
        const $allItems = $carousel.find('.carousel-item');
        const $activeItem = $carousel.find('.carousel-item.active').first();
        let activeIndex = 0;
        
        $allItems.each(function(index) {
            if ($(this).is($activeItem)) {
                activeIndex = index;
                return false;
            }
        });
        
        const images = [];
        $allItems.each(function(idx) {
            const $img = $(this).find('.carousel-main-img');
            if ($img.length) {
                images.push({
                    fullscreen: $img.data('fullscreen'),
                    alt: $img.attr('alt') || 'Imagen de habitación'
                });
            }
        });
        
        if (images.length === 0) return;
        
        let carouselHTML = `
            <style>
                #galleryCarousel .carousel-item {
                    display: none !important;
                    position: absolute !important;
                    top: 0 !important;
                    left: 0 !important;
                    width: 100% !important;
                    height: 90vh !important;
                }
                #galleryCarousel .carousel-item.active {
                    display: block !important;
                    position: relative !important;
                }
            </style>
            <div class="carousel-inner" style="position: relative; width: 100%; height: 90vh;">`;
        
        images.forEach((img, index) => {
            const isActive = index === activeIndex ? 'active' : '';
            carouselHTML += `
                <div class="carousel-item ${isActive}">
                    <div style="display: flex; align-items: center; justify-content: center; height: 100%; width: 100%;">
                        <img src="${img.fullscreen}" class="img-fluid" alt="${img.alt}" style="max-height: 90vh; max-width: 100%; object-fit: contain;">
                    </div>
                </div>`;
        });
        
        carouselHTML += '</div>';
        
        if (images.length > 1) {
            carouselHTML += `
                <button class="carousel-control-prev" type="button" data-bs-target="#galleryCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Anterior</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#galleryCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Siguiente</span>
                </button>`;
        }
        
        const $modal = $('#galleryModal');
        const $galleryCarousel = $('#galleryCarousel');
        
        if ($galleryCarousel.data('bs.carousel')) {
            $galleryCarousel.carousel('dispose');
        }
        
        $galleryCarousel.off();
        $galleryCarousel.html(carouselHTML);
        
        // Inicializar contador
        $('#galleryCurrentSlide').text(activeIndex + 1);
        $('#galleryTotalSlides').text(images.length);
        
        $modal.modal('show');
        
        $modal.one('shown.bs.modal', function() {
            setTimeout(() => {
                $galleryCarousel.carousel({ interval: false, wrap: true, keyboard: true, ride: false });
                
                $galleryCarousel.on('slide.bs.carousel', function(e) {
                    $('#galleryCurrentSlide').text(e.to + 1);
                });
            }, 150);
        });
    },
    _onImageClick: function(ev) {
        const $img = $(ev.currentTarget);
        const roomTypeId = $img.data('room-type-id');
        const $btn = $(`.btn-ver-galeria[data-room-type-id="${roomTypeId}"]`).first();
        if ($btn.length) $btn.trigger('click');
    },

    _onSelectRoomType: function (ev) {
        ev.preventDefault();
        ev.stopPropagation(); 
        
        if (this.isBusy) {
            console.warn('⚠️ Clic ignorado: El sistema ya está procesando una solicitud.');
            return;
        }

        const $btn = $(ev.currentTarget);
        
        try {
            $btn.closest('.room-type-card').find('.carousel').carousel('pause');
        } catch(e) {}

        if ($btn.prop('disabled') || $btn.hasClass('disabled')) return;
        
        let tipoId = $btn.data('tipo-id');
        let tipoName = $btn.data('tipo-name');
        
        if (!tipoId) {
            const $card = $btn.closest('.room-type-card');
            tipoId = $card.data('tipo-id');
            tipoName = $card.data('tipo-name');
        }
        
        if (!tipoId) {
            console.warn('⚠️ Click en botón de selección sin ID. Revisa el XML.');
            return;
        }

        this.isBusy = true;
        
        const checkIn = this.$('#fecha_check_in').val();
        const checkOut = this.$('#fecha_check_out').val();

        toggleLoading($btn, true);
        this.$alertContainer.empty();

        $.ajax({
            url: '/habitaciones/especificas_disponibles',
            type: 'POST',
            data: {
                tipo_id: tipoId,
                check_in: checkIn,
                check_out: checkOut
            },
            success: (data) => {
                try {
                    if (!data || !data.success) {
                        this._showError(data && data.error ? data.error : "Error al cargar habitaciones.");
                        return;
                    }

                    this.$('#specific_rooms_container').html(data.html);
                    this.$('#selected_type_name').text(tipoName);
                    
                    this._initDoorAnimations();
                    this._updateStepVisibility(3);
                    
                } catch (e) {
                    console.error('❌ Error renderizando la respuesta del Paso 3:', e);
                    this._showError("Error técnico al mostrar las habitaciones. Por favor intenta de nuevo.");
                }
            },
            error: (xhr) => {
                let msg = "Error al cargar habitaciones.";
                try {
                    const j = JSON.parse(xhr.responseText);
                    if (j && j.error) msg = j.error;
                } catch (e) {}
                this._showError(msg);
            },
            complete: () => {
                toggleLoading($btn, false);
                this.isBusy = false;
            }
        });
    },

    _initDoorAnimations: function() {
        const self = this;
        
        const cards = this.$('.door-room-card');
        if (cards.length === 0) {
            console.warn('⚠️ No se encontraron tarjetas de puerta (.door-room-card).');
        }

        cards.each(function() {
            const $card = $(this);
            const $marco = $card.find('.marco-negro');
            const $boton = $card.find('.btn-door-select');
            
            $marco.off('click').on('click', function(e) {
                if (!$(e.target).closest('.btn-door-select').length) {
                    if (self.isBusy) return;
                    
                    self._abrirPuerta($card);
                    
                    setTimeout(() => {
                        let roomId = $boton.length ? $boton.data('room-id') : $card.data('room-id');
                        let roomName = $boton.length ? $boton.data('room-name') : $card.find('.numero-habitacion').text().trim();
                        
                        if (roomId) {
                            self._selectDoorRoom(roomId, roomName);
                        }
                    }, 1200);
                }
            });
            
            if ($boton.length) {
                $boton.off('click').on('click', function(e) {
                    e.stopPropagation();
                    if (self.isBusy) return;

                    self._abrirPuerta($card);
                    
                    setTimeout(() => {
                        const roomId = $boton.data('room-id');
                        const roomName = $boton.data('room-name');
                        self._selectDoorRoom(roomId, roomName);
                    }, 1200);
                });
            }
        });
    },

    _abrirPuerta: function($card) {
        const $puerta = $card.find('.puerta-img');
        const $boton = $card.find('.btn-door-select');
        const $numero = $card.find('.numero-habitacion');

        if ($puerta.hasClass('abriendo')) return;

        $puerta.addClass('abriendo');
        if ($numero.length) $numero.addClass('abriendo');
        if ($boton.length) $boton.addClass('strobo');

        setTimeout(() => {
            $puerta.addClass('opened');
            if ($numero.length) $numero.addClass('opened');
        }, 600);

        setTimeout(() => {
            if ($boton.length) $boton.removeClass('strobo');
        }, 1200);
    },

    _selectDoorRoom: function(roomId, roomName) {
        if (this.isBusy) return;
        this.isBusy = true;

        this.$('#selected_room_name').text(roomName);
        this.$('#final_habitacion_id').val(roomId);
    
        const checkIn = this.$('#fecha_check_in').val();
        const checkOut = this.$('#fecha_check_out').val();
        
        const finalCheckIn = checkIn + " 12:00";
        const finalCheckOut = checkOut + " 12:00";
    
        this.$('#final_check_in').val(finalCheckIn);
        this.$('#final_check_out').val(finalCheckOut);
        
        const formatDate = (dateStr) => {
            const date = new Date(dateStr);
            return date.toLocaleDateString('es-MX', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        };
        
        this.$('#display_check_in').text(formatDate(finalCheckIn));
        this.$('#display_check_out').text(formatDate(finalCheckOut));
    
        this._calculateAndShowPrice(roomId, finalCheckIn, finalCheckOut);
        this._updateStepVisibility(4);
    },

    _onSelectSpecificRoom: function (ev) {
        ev.preventDefault();
        
        if (this.isBusy) return;
        this.isBusy = true;

        const btn = $(ev.currentTarget);
        const roomId = btn.data('room-id');
        const roomName = btn.data('room-name');
    
        this.$('#selected_room_name').text(roomName);
        this.$('#final_habitacion_id').val(roomId);
    
        const checkIn = this.$('#fecha_check_in').val();
        const checkOut = this.$('#fecha_check_out').val();
        
        const finalCheckIn = checkIn + " 12:00";
        const finalCheckOut = checkOut + " 12:00";
    
        this.$('#final_check_in').val(finalCheckIn);
        this.$('#final_check_out').val(finalCheckOut);
        
        const formatDate = (dateStr) => {
            const date = new Date(dateStr);
            return date.toLocaleDateString('es-MX', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        };
        
        this.$('#display_check_in').text(formatDate(finalCheckIn));
        this.$('#display_check_out').text(formatDate(finalCheckOut));
    
        this._calculateAndShowPrice(roomId, finalCheckIn, finalCheckOut);
        this._updateStepVisibility(4);
    },

    _calculateAndShowPrice: function(habitacionId, checkIn, checkOut) {
        const self = this;
        const $loading = $('#price-loading');
        const $content = $('#price-breakdown-content');
        const $error = $('#price-error');
        
        $loading.removeClass('d-none');
        $content.addClass('d-none');
        $error.addClass('d-none');
        
        console.log('💰 Calculando precio para habitación:', habitacionId);
        
        $.ajax({
            url: '/habitaciones/calcular_precio',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                jsonrpc: "2.0",
                method: "call",
                params: {
                    habitacion_id: habitacionId,
                    check_in: checkIn,
                    check_out: checkOut
                }
            }),
            success: function(response) {
                if (response.result && response.result.success) {
                    const data = response.result;
                    
                    $content.html(data.desglose);
                    $loading.addClass('d-none');
                    $content.removeClass('d-none');
                    
                    self.precioTotal = data.total;
                } else {
                    console.error('❌ Error en cálculo:', response.result.error);
                    $loading.addClass('d-none');
                    $error.removeClass('d-none');
                    $error.text(response.result.error || 'Error al calcular precio');
                }
            },
            error: function(xhr, status, error) {
                console.error('❌ Error AJAX:', error);
                $loading.addClass('d-none');
                $error.removeClass('d-none');
            },
            complete: function() {
                self.isBusy = false;
            }
        });
    },

    _onBackToTypes: function () { 
        this._updateStepVisibility(2); 
    },
    
    _onBackToDates: function () { 
        this._updateStepVisibility(1); 
    },
    
    _onBackToRooms: function () { 
        this._cerrarTodasLasPuertas();
        this._updateStepVisibility(3); 
    },

    _cerrarTodasLasPuertas: function() {
        this.$('.door-room-card').each(function() {
            const $card = $(this);
            const $puerta = $card.find('.puerta-img');
            const $numero = $card.find('.numero-habitacion');
            
            $puerta.removeClass('abriendo opened');
            if ($numero.length) {
                $numero.removeClass('abriendo opened');
            }
        });
    },

    _showError: function (msg) {
        this.$alertContainer.html(`
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fa fa-exclamation-triangle"></i> ${msg}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `);
        if (this.$alertContainer.length) {
            this.$alertContainer[0].scrollIntoView({behavior: 'smooth', block: 'start'});
        }
    },

    _showSuccess: function (msg) {
        this.$alertContainer.html(`
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fa fa-check-circle"></i> ${msg}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `);
        if (this.$alertContainer.length) {
            this.$alertContainer[0].scrollIntoView({behavior: 'smooth', block: 'start'});
        }
    },
});
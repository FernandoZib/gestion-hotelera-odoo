/** @odoo-module **/

import { registry } from "@web/core/registry";

console.log("🎯 Iniciando interceptor de carga de imágenes...");

// Servicio personalizado para interceptar la carga de archivos
const imageUploadNotificationService = {
    start(env) {
        // Interceptar todos los eventos de cambio en inputs de tipo file
        document.addEventListener('change', async function(event) {
            const target = event.target;
            // Solo procesar inputs de tipo file con archivos de imagen
            if (target.tagName === 'INPUT' && 
                target.type === 'file' && 
                target.files && 
                target.files.length > 0 &&
                target.accept && 
                target.accept.includes('image')) {
                
                const files = target.files;
                // Mostrar notificación de carga
                env.services.notification.add(
                    `⏳ Subiendo ${files.length} imagen(es)...`,
                    {
                        type: "info",
                    }
                );
                
                // Esperar a que se carguen y aparezca el banner
                setTimeout(() => {
                    env.services.notification.add(
                        `✅ ${files.length} imagen(es) lista(s) - Recuerda guardar el formulario`,
                        {
                            type: "success",
                        }
                    );
                }, 1500);
        
            }
        }, true); // useCapture = true para interceptar antes
        
        return {};
    }
};

registry.category("services").add("imageUploadNotification", imageUploadNotificationService);